echo "< ==== EJECUTAR EL SIGUIENTE COMANDO ==== >"

echo "sdk use grails 3.3.16; sdk use gradle 3.5; sdk use groovy 2.5.5;"