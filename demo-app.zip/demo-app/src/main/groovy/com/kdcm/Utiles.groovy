package com.jpicadoyasociados

import com.kdcm.FileUploadService
import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang.builder.EqualsBuilder
import org.apache.commons.lang.builder.HashCodeBuilder
import org.apache.commons.logging.LogFactory

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.NumberFormat
import java.time.Duration

class Utiles {

    private static final logger = LogFactory.getLog(this)



//    //lectura de un número decimal con punto (.) como separador decimal
//    static double lecturaNumero(String number) {
//        double val = 0.0d
//        NumberFormat nf_in = NumberFormat.getNumberInstance(Locale.US);
//        try {
//            val = nf_in.parse(number).doubleValue();
//        }
//        catch (e) {
//            //si se digita un número incorrecto se devuelve 0.0
//            logger.error("lecturaNumero: número introducido incorrecto: " + number + " (se asigna 0.0)")
//            val = 0.0d
//        }
//        return val
//    }
//
//    static String mostrarNumeroDecimal(double number){
//        DecimalFormat df = new DecimalFormat("###,###,###,###,##0.00");
//        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
//        dfs.setDecimalSeparator('.' as char);
//        dfs.setGroupingSeparator(',' as char);
//        df.setDecimalFormatSymbols(dfs);
//        return df.format(number)
//    }
//
//    static String mostrarNumeroEntero(long number){
//        DecimalFormat df = new DecimalFormat("###,###,###,###,##0");
//        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
//        //dfs.setDecimalSeparator('.' as char);
//        dfs.setGroupingSeparator(',' as char);
//        //df.setDecimalFormatSymbols(dfs);
//        return df.format(number)
//    }
//    //No se usa
//    static String mostrarNumeroEntero(int number){
//        DecimalFormat df = new DecimalFormat("###,###,###,###,##0");
//        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
//        //dfs.setDecimalSeparator('.' as char);
//        dfs.setGroupingSeparator(',' as char);
//        //df.setDecimalFormatSymbols(dfs);
//        return df.format(number)
//    }
//
//    static String paddinLeftNumero(int numero, int numeroPosiciones){
//        String salida = numero.toString()
//        salida = salida.padLeft(numeroPosiciones, "0")
//        return salida
//    }
//
//    static long obtenerDiferenciaFechas(Date fechaInicial, Date fechaFinal){
//        long diffInMillies = Math.abs(fechaFinal.getTime() - fechaInicial.getTime());
//        return diffInMillies
//    }
//
//    /*
//    static long obtenerDiferenciaFechasHabiles(Date fechaInicial, Date fechaFinal){
//        //2019-02-13 Al sumar este dia se estaba calculando mal en los procesos, donde haga falta el dia
//        //se debe sumar antes de llamar a este metodo.
//        //Date fechaAux = fechaFinal  + 1
//        Date fechaAux = fechaFinal
//        //long diffInMillies = Math.abs(fechaFinal.getTime() - fechaInicial.getTime());
//        long diffInMillies = Math.abs(fechaAux.getTime() - fechaInicial.getTime());
//        //2022-01-11 si se deja esta variable como int luego al multiplicarla por alguna razon en diasAResarMillies no cabe, aunque sea long
//        //int diasARestar = contarFeriadosYDiasNoHabiles(fechaInicial, fechaFinal)
//        long diasARestar = contarFeriadosYDiasNoHabiles(fechaInicial, fechaFinal)
//        long diasAResarMillies = diasARestar * 24 * 60 * 60 * 1000
//        long salida = diffInMillies - diasAResarMillies
//         logger.info("obtenerDiferenciaFechasHabiles - diffInMillies: " + diffInMillies)
//         logger.info("obtenerDiferenciaFechasHabiles - diasAResarMillies: " + diasAResarMillies)
//         logger.info("obtenerDiferenciaFechasHabiles - salida: " + salida)
//        return salida
//    }
//
//    static int obtenerDiferenciasFechasHabilesEnDias(Date fechaInicial, Date fechaFinal){
//        long diasEnMilisegundos = Utiles.obtenerDiferenciaFechasHabiles(fechaInicial, fechaFinal)
//        int dias = (diasEnMilisegundos / 1000) / 60 / 60 / 24
//        return dias
//    }
//     */
//
//    //devuelve un string con unas milisegundos pasadas a texto
//    static String pasarMilisegundosATexto(long milisegundos){
//        if(milisegundos==0){
//            return "--"
//        }
//        long different = milisegundos
//        long secondsInMilli = 1000;
//        long minutesInMilli = secondsInMilli * 60;
//        long hoursInMilli = minutesInMilli * 60;
//        long daysInMilli = hoursInMilli * 24;
//
//        long elapsedDays = different / daysInMilli;
//        different = different % daysInMilli;
//
//        long elapsedHours = different / hoursInMilli;
//        different = different % hoursInMilli;
//
//        long elapsedMinutes = different / minutesInMilli;
//        different = different % minutesInMilli;
//
//        long elapsedSeconds = different / secondsInMilli;
//
//        String salida = " "
//        if(elapsedDays>0){
//            if(elapsedDays==1) {
//                salida = salida + elapsedDays + " día "
//            }
//            else {
//                salida = salida + elapsedDays + " días "
//            }
//        }
//
//        if(elapsedHours>0){
//            if(elapsedHours==1) {
//                salida = salida + elapsedHours + " hora "
//            }
//            else {
//                salida = salida + elapsedHours + " horas "
//            }
//        }
//
//        if(elapsedMinutes>0){
//            if(elapsedMinutes==1) {
//                salida = salida + elapsedMinutes + " minuto "
//            }
//            else {
//                salida = salida + elapsedMinutes + " minutos "
//            }
//        }
//
//        if(elapsedDays==0){
//            if(elapsedSeconds>0){
//                if(elapsedSeconds==1){
//                    salida = salida + elapsedSeconds + " segundo "
//                }
//                else {
//                    salida = salida + elapsedSeconds + " segundos "
//                }
//            }
//        }
//
//        return salida
//    }
//
//    //devuelve un string con unas dias pasadas a texto
//    static String pasarDiasDoubleAStr(double dias) {
//        String salida = "No valido"
//        int diasPrevistos = dias.trunc()
//        int horasPrevistas = ((dias - diasPrevistos) * 24)
//        if(diasPrevistos==0){
//            salida = [horasPrevistas, " horas"].findAll({it != null}).join()
//        }
//        else {
//            if(horasPrevistas==0){
//                if(diasPrevistos == 1){
//                    salida = [diasPrevistos, " día "].findAll({it != null}).join()
//                }
//                else {
//                    salida = [diasPrevistos, " días "].findAll({it != null}).join()
//                }
//
//            }
//            else {
//                if(diasPrevistos == 1){
//                    salida = [diasPrevistos, " día ", horasPrevistas, " horas"].findAll({it != null}).join()
//                }
//                else {
//                    salida = [diasPrevistos, " días ", horasPrevistas, " horas"].findAll({it != null}).join()
//                }
//            }
//        }
//        return salida
//
//    }
//
//    //devuelve un string con unas horas pasadas a texto
//    static String pasarHorasDoubleAStr(double horas) {
//        String salida = "No valido"
//        int horasPrevistas = horas.trunc()
//        int minutosPrevistos = ((horas - horasPrevistas) * 10) * 6
//        if(horasPrevistas==0){
//            salida = [minutosPrevistos, " minutos"].findAll({it != null}).join()
//        }
//        else {
//            if(minutosPrevistos==0){
//                if(horasPrevistas == 1){
//                    salida = [horasPrevistas, " hora "].findAll({it != null}).join()
//                }
//                else {
//                    salida = [horasPrevistas, " horas "].findAll({it != null}).join()
//                }
//
//            }
//            else {
//                if(horasPrevistas == 1){
//                    salida = [horasPrevistas, " hora ", minutosPrevistos, " minutos"].findAll({it != null}).join()
//                }
//                else {
//                    salida = [horasPrevistas, " horas ", minutosPrevistos, " minutos"].findAll({it != null}).join()
//                }
//            }
//        }
//        return salida
//    }
//
//    static String obtenerDuracionHastaAhoraStr(Date fecha, int limiteNiveles = 2) {
//        return pasarDiferenciaFechasAStr(fecha, new Date(), limiteNiveles)
//    }
//
//    //devuelve un String con la direferencia de tiempo entre 2 fechas
//    def static String pasarDiferenciaFechasAStr(Date fechaInicial, Date fechaFinal, int limiteNiveles = 2){
//        //	 logger.info("pasarDiferenciaFechasAStr() - fechaInicial: " + fechaInicial.format("yyyy-MM-dd") + " - fechaFinal: " + fechaFinal.format("yyyy-MM-dd"))
//        String salida = ""
//
//        Map diff = getDiffernceInDates(fechaInicial, fechaFinal)
//        int numeroNiveles = 0
//        if(diff.years && numeroNiveles < limiteNiveles){
//            salida =  diff.years ? diff.years + " año${(diff.years>1)?'s':''} " : ""
//            numeroNiveles++
//        }
//        if(diff.weeks && numeroNiveles < limiteNiveles){
//            salida += diff.weeks ? diff.weeks + " semana${(diff.weeks>1)?'s':''} " : ""
//            numeroNiveles++
//        }
//        if(diff.days && numeroNiveles < limiteNiveles){
//            salida += diff.days ? diff.days + " día${(diff.days>1)?'s':''} " : ""
//            numeroNiveles++
//        }
//        if(diff.hours && numeroNiveles < limiteNiveles){
//            salida += diff.hours ? diff.hours + " hora${(diff.hours>1)?'s':''} " : ""
//            numeroNiveles++
//        }
//
//        if(diff.minutes && numeroNiveles < limiteNiveles){
//            salida += diff.minutes ? diff.minutes + " minuto${(diff.minutes>1)?'s':''} " : ""
//            numeroNiveles++
//        }
//
//        if(diff.seconds && numeroNiveles < limiteNiveles){
//            salida += diff.seconds ? diff.seconds + " segundo${(diff.seconds>1)?'s':''}" : ""
//            numeroNiveles++
//        }
//
//        return salida
//    }
//
//    private static Map getDiffernceInDates(Date oldDate, Date newDate = new Date()) {
//        /* FUNCIONA AXULIZAR PARA CALCULAR LA DIREFERENCIA ENTRE 2 FECHAS*/
//        Long difference = newDate.time - oldDate.time
//        Map diffMap =[:]
//        difference = difference / 1000
//
//        // logger.info("difference (segundos): " + difference)
//
//        diffMap.seconds = difference % 60
//        difference = (difference - diffMap.seconds) / 60
//        // logger.info("difference: " + difference)
//
//        diffMap.minutes = difference % 60
//        difference = (difference - diffMap.minutes) / 60
//        // logger.info("difference (horas): " + difference)
//
//        diffMap.hours = difference % 24
//        difference = (difference - diffMap.hours) / 24
//        // logger.info("difference (dias): " + difference)
//
//        diffMap.years = (difference / 365).toInteger()
//        if(diffMap.years) {
//            difference = (difference) % 365
//            // logger.info("difference (días): " + difference)
//            int numeroBisiestos = obtenerNumeroBisiestos(oldDate, newDate)
//            difference = difference - numeroBisiestos
//            // logger.info("numeroBisiestos: " + numeroBisiestos)
//            // logger.info("difference (días): " + difference)
//        }
//
//
//        diffMap.days = difference % 7
//        diffMap.weeks = (difference - diffMap.days) / 7
//        return diffMap
//    }
//
//    private static int obtenerNumeroBisiestos(Date oldDate, Date newDate){
//        int annioInicial = oldDate.format("yyyy") as int
//        int annioFinal = newDate.format("yyyy") as int
//        if(annioInicial == annioFinal){
//            return 0
//        }
//        if(annioFinal < annioInicial){
//            return 0
//        }
//        int numeroBisiestos = 0
//
//        for(int i=annioInicial; i<=annioFinal; i++){
//            if(esAnnioBisiesto(i)){
//                numeroBisiestos+=1
//                if(i==annioInicial){
//                    if((newDate.format("MM") as int) >= 3){
//                        //si el primer annio es bisiesto pero la fecha es mayor o igual a marzo, no se debe contar
//                        numeroBisiestos-=1
//                    }
//                }
//                if(i==annioFinal){
//                    if((newDate.format("MM") as int) < 3){
//                        //si el ultimo annio es bisiesto pero la fecha es menor a marzo, no se debe contar
//                        numeroBisiestos-=1
//                    }
//                }
//            }
//        }
//
//        return numeroBisiestos
//    }
//
//    public static boolean esAnnioBisiesto(int annio){
//        if (annio % 400 == 0){
//            return true
//        }
//        if (annio % 100 == 0){
//            return false
//        }
//        if (annio % 4 == 0){
//            return true
//        }
//        return false
//    }
//
//    static lecturaFechaFiltros(String fecha, Date fechaInicial, Date fechaFinal) throws Exception {
//        try {
//            if(fecha.size()==4 || fecha.size()==5){
//                //SE FILTRA POR AÑO
//                if(fecha.size()==5){
//                    fechaInicial = Date.parse('yyyy-MM-dd', fecha+"01-01")
//                }
//                else {
//                    fechaInicial = Date.parse('yyyy-MM-dd', fecha+"-01-01")
//                }
//                use(groovy.time.TimeCategory) {
//                    fechaFinal = fechaInicial + 1.year
//                    fechaFinal = fechaFinal - 1.days
//                }
//            }
//            else {
//                if(fecha.size()==6 || fecha.size()==7 || fecha.size()==8){
//                    //SE FILTRA POR MES
//                    if(fecha.size()==8){
//                        fechaInicial = Date.parse('yyyy-MM-dd', fecha+"01")
//                    }
//                    else {
//                        fechaInicial = Date.parse('yyyy-MM-dd', fecha+"-01")
//                    }
//                    use(groovy.time.TimeCategory) {
//                        fechaFinal = fechaInicial + 1.month
//                        fechaFinal = fechaFinal - 1.days
//                        fecha = fechaInicial.format("yyyy-MM")
//                    }
//                }
//                else {
//                    if(fecha.size()==10 || fecha.size()==9){
//                        //SE FILTRA POR DIA
//                        fechaInicial = Date.parse('yyyy-MM-dd', fecha)
//                        fechaFinal = fechaInicial.clone()
//                    }
//                }
//            }
//
//            fechaFinal = fechaFinalDia(fechaFinal)
//            logger.info("-- lecturaFechaFiltros - fecha: " + fecha)
//            logger.info("---- lecturaFechaFiltros - fechaInicial: " + fechaInicial.format("yyyy-MM-dd HH:mm:ss"))
//            logger.info("---- lecturaFechaFiltros - fechaFinal: " + fechaFinal.format("yyyy-MM-dd HH:mm:ss"))
//            return [fecha, fechaInicial, fechaFinal]
//        }
//        catch (Exception e) {
//            logger.info(e)
//            throw e
//        }
//    }
//
//    static Date fechaFinalDia(Date fecha){
//        Date fechaAux = fecha
//        fechaAux.set(hourOfDay: 23, minute: 59, second: 59)
//        return fechaAux
//    }
//
//    //lectura de un una fecha que podría tener algún campo no seleccionado
//    static Date lecturaFechaNullable(fecha) {
//        try {
//            if(fecha == "null") {
//                logger.error("fecha con valor null")
//                return null
//            }
//            else {
//                if((fecha.getClass() == Date)) {
//                    return fecha
//                }
//            }
//        }
//        catch (e) {
//            logger.error("lecturaFechaNullable: fecha mal introducido incorrecto: " + fecha + " (se asigna null)")
//        }
//        return null
//    }
//
//    static Date validarParametrosFecha(params, nombreParametro){
//        int annoFecha = params."${nombreParametro}_year" as int
//        int mesFecha = params."${nombreParametro}_month" as int
//        int diaFecha = params."${nombreParametro}_day" as int
//
//        params."${nombreParametro}_year" = null
//        params."${nombreParametro}_month" = null
//        params."${nombreParametro}_day" = null
//        params."${nombreParametro}" = null
//
//        Calendar calendarDate = new GregorianCalendar()
//
//        calendarDate.set(Calendar.YEAR, annoFecha);
//        calendarDate.set(Calendar.MONTH, mesFecha - 1);
//
//        if(mesFecha == 1 || mesFecha == 3 || mesFecha == 5 || mesFecha == 7 || mesFecha == 8 || mesFecha == 10 || mesFecha == 12){
//            //meses de 31 dias, no hay nada que hacer
//            calendarDate.set(Calendar.DAY_OF_MONTH, diaFecha);
//        }
//        else {
//            if(mesFecha == 2) {
//                //febrero
//                if(esAnnioBisiesto(annoFecha)){
//                    if(diaFecha>29){
//                        calendarDate.set(Calendar.DAY_OF_MONTH, 29);
//                    }
//                    else {
//                        calendarDate.set(Calendar.DAY_OF_MONTH, diaFecha);
//                    }
//                }
//                else {
//                    if(diaFecha>28){
//                        calendarDate.set(Calendar.DAY_OF_MONTH, 28);
//                    }
//                    else {
//                        calendarDate.set(Calendar.DAY_OF_MONTH, diaFecha);
//                    }
//                }
//            }
//            else {
//                //meses de 30 dias
//                if(diaFecha>30){
//                    calendarDate.set(Calendar.DAY_OF_MONTH, 30);
//                }
//                else {
//                    calendarDate.set(Calendar.DAY_OF_MONTH, diaFecha);
//                }
//            }
//        }
//
//        //calendarDate.set(Calendar.HOUR, fecha.hours);
//        if(params."${nombreParametro}_hour"){
//            calendarDate.set(Calendar.HOUR_OF_DAY, params."${nombreParametro}_hour" as int);
//        }
//        else {
//            calendarDate.set(Calendar.HOUR_OF_DAY, 0);
//        }
//
//        if(params."${nombreParametro}_minute"){
//            calendarDate.set(Calendar.MINUTE, params."${nombreParametro}_minute" as int);
//            params."${nombreParametro}_minute" = null
//        }
//        else {
//            calendarDate.set(Calendar.SECOND, 0);
//            params."${nombreParametro}_second" = null
//        }
//
//
//        calendarDate.set(Calendar.MILLISECOND, 0);
//
//        return calendarDate.getTime()
//    }
//
//    static String mostrarPorcentaje(double porcentaje) {
//        DecimalFormat df = new DecimalFormat("###,###,###,###,##0.00");
//        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
//        dfs.setDecimalSeparator('.' as char);
//        dfs.setGroupingSeparator(',' as char);
//        df.setDecimalFormatSymbols(dfs);
//
//        return [df.format(porcentaje),"%"].findAll({it != null}).join();
//    }
//
//    static String mostrarPorcentajeEntero(double porcentaje) {
//        DecimalFormat df = new DecimalFormat("###,###,###,###,##0");
//        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
//        dfs.setDecimalSeparator('.' as char);
//        dfs.setGroupingSeparator(',' as char);
//        df.setDecimalFormatSymbols(dfs);
//
//        return [df.format(porcentaje),"%"].findAll({it != null}).join();
//    }
//
//    //Devuelve si un objeto es una colección o un objeto sólo
//    static boolean isCollectionOrArray(object) {
//        [Collection, Object[]].any { it.isAssignableFrom(object.getClass()) }
//    }
//
//
//    /*
//    //Calcula la diferente en meses entre 2 fechas
//    def static mesesDiferencia(from, to){
//        def cfrom = new GregorianCalendar(time:from)
//        def cto   = new GregorianCalendar(time:to)
//        cto.add(Calendar.DAY_OF_MONTH, 1) //sumo un día a la fecha destino
//        return ((cto.get(Calendar.YEAR) - cfrom.get(Calendar.YEAR)) * 12) + ((cto.get(Calendar.MONTH) - cfrom.get(Calendar.MONTH)))
//    }
//     */
//
//    def static diferenciaEntreFechasEnMeses(from, to){
//        def cfrom = new GregorianCalendar(time:from)
//        def cto   = new GregorianCalendar(time:to)
//        int yearsInBetween = cto.get(Calendar.YEAR) - cfrom.get(Calendar.YEAR);
//        int monthsDiff = cto.get(Calendar.MONTH) - cfrom.get(Calendar.MONTH);
//        long diferenciaEnMeses = yearsInBetween*12 + monthsDiff;
//        return diferenciaEnMeses
//    }
//
//    public static ArrayList aplicarOffset(ArrayList array, int max, int offset) {
//        //println array
//        if(array.size()<=max){
//            logger.info("aplicarOffset: salida rapida porque el array tiene menos elementos de max")
//            return array
//        }
//        else {
//            ArrayList salida = new ArrayList()
//            if(offset < array.size()) {
//                logger.info("aplicarOffset: offset es menor al array.size")
//                for (int i=offset;i<offset + max && i<array.size(); i++) {
//                    salida.add(array[i])
//                }
//            }
//            else {
//                logger.info("aplicarOffset: offset es mayor o  al array.size")
//                for (int i=0;i<max && i<array.size(); i++) {
//                    salida.add(array[i])
//                }
//            }
//            return salida
//        }
//    }
//
//    public static usuarioActualTienePerfil(request, perfil){
//        return new org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper(request, "ROLE_").isUserInRole(perfil)
//    }
//
//    static boolean equals(Object one, Object another) {
//        one != null && another != null &&
//                ((one.respondsTo('instanceOf') && another.instanceOf(one.getClass())) ||
//                        one.getClass().isInstance(another)) &&
//                (one.is(another) ||
//                        one.getClass().equalsProperties.inject(new EqualsBuilder()) {
//                            builder, property ->
//                                builder.append(one[property], another[property])
//                        }.isEquals())
//    }
//
//    /*
//    static int hashCode(Object one) {
//        one.getClass().equalsProperties.inject(new HashCodeBuilder()) {
//            builder, property ->
//            builder.append(this[property])
//        }.toHashCode()
//    }
//    */
//
//    static String limpiarNombreArchivo(String nombre){
//        String salida = nombre
//        salida = FilenameUtils.removeExtension(salida)
//        salida = salida.replaceAll("[^a-zA-Z0-9\\._]+", "_");
//        if(salida.size()>100){
//            salida = salida.substring(0, 99)
//        }
//        return salida
//    }
//
//    static public obtenerGrailsApplication(){
//        def grailsApplication = grails.util.Holders.getGrailsApplication()
//        return grailsApplication
//    }
//
//    public static String generarSufijoIDsPublicos(){
//        return generarCadenaAleatoria(6)
//    }
//
//    public static String generarCadenaAleatoria(int longitud) {
//        //String charset = (('a'..'z') + ('A'..'Z') + ('0'..'9')).join()
//        String charset = (('0'..'9')).join()
//        String randomString = org.apache.commons.lang.RandomStringUtils.random(longitud, charset.toCharArray())
//        //String randomString = org.apache.commons.lang.RandomStringUtils.random(9, true, true)
//        return randomString
//    }
//
//    public static String obtenerURLSistemaInterna(){
//        if(grails.util.Holders.config.grails.serverURLInterna!=''){
//            String url = grails.util.Holders.config.grails.serverURLInterna
//            if(url==null){
//                return ""
//            }
//            return url.trim()
//        }
//        return ""
//    }
//
//    public static int obtenerNumeroMaximoRepeticionesObjetivos(){
//        if(grails.util.Holders.config.evaluacionDesempeno.repeticionesObjetivos!=''){
//            String numero = grails.util.Holders.config.evaluacionDesempeno.repeticionesObjetivos
//            if(numero.isNumber()){
//                return numero as int
//            }
//        }
//        return -1
//    }
//
//    public static String obtenerTemaSinUsuario(){
//        if(grails.util.Holders.config.tema.sinUsuario!=''){
//            String temaSinUsuario = grails.util.Holders.config.tema.sinUsuario
//            if(temaSinUsuario==null){
//                return ""
//            }
//            return temaSinUsuario.trim()
//        }
//        return "Default"
//    }
//
//    public static String obtenerEspacioUtilizadoDirectorioBinarios() {
//        logger.info("obtenerEspacioUtilizadoDirectorioBinarios()")
//        FileUploadService fileUploadService = grails.util.Holders.applicationContext.getBean('fileUploadService') //as FileUploadService
//        String directorioRaizRuta = fileUploadService.obtenerRutaAbsolutaMultimedia()
//        // logger.info("-- directorioRaizRuta: " + directorioRaizRuta)
//        String salida = "" //directorioRaizRuta +  " - ocupa: "
//        def directorioRaiz = new File(directorioRaizRuta)
//        if(directorioRaiz.exists()){
//            long directorioSize = directorioRaiz.directorySize() // en bytes
//            //salida = salida + " " + directorioSize + "B "
//
//            //2019-10-24 - Se cambia el factor de conversion a 1024
//            //int factorConversion = 1000
//            int factorConversion = 1024
//            double directorioSizeAux = (directorioSize / factorConversion) // en kilobytes
//            //salida = salida + " -> " + directorioSizeAux.round(2).toString() + "KB "
//            directorioSizeAux = (directorioSizeAux / factorConversion) // en megabytes
//            salida = salida + directorioSizeAux.round(2).toString() + "MB "
//            directorioSizeAux = (directorioSizeAux / factorConversion) // en gigabytes
//            salida = salida + " (" + directorioSizeAux.round(2).toString() + "GB) "
//        } else {
//            salida = "No se ha cargado ningún archivo al sistema"
//        }
//        return salida
//        //return directorioSizeAux.round(2).toString() + " GB"
//    }
//
//
//    public static obtenerRutaAbsolutaMultimedia(){
//        FileUploadService fileUploadService = grails.util.Holders.applicationContext.getBean('fileUploadService') //as FileUploadService
//        return fileUploadService.obtenerRutaAbsolutaMultimedia()
//    }
//
//    public static cleanUpGorm() {
//        logger.info("cleanUpGorm()")
//        //def propertyInstanceMap = org.grails.plugins.domain.DomainClassGrailsPlugin.PROPERTY_INSTANCE_MAP
//        def sessionFactory =  grails.util.Holders.applicationContext.getBean('sessionFactory')
//        def session = sessionFactory.currentSession
//        //def session =  org.springframework.web.context.request.RequestContextHolder.currentRequestAttributes().getSession()
//        session.flush()
//        session.clear()
//        //propertyInstanceMap.get().clear()
//    }
//
//    def static disableSSLCheck() {
//        def nullTrustManager = [
//                checkClientTrusted: { chain, authType -> },
//                checkServerTrusted: { chain, authType -> },
//                getAcceptedIssuers: { null }
//        ]
//
//        def nullHostnameVerifier = [
//                verify: { hostname, session -> true }
//        ]
//
//        SSLContext sc = SSLContext.getInstance("SSL")
//        sc.init(null, [nullTrustManager as X509TrustManager] as TrustManager[], null)
//        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory())
//        HttpsURLConnection.setDefaultHostnameVerifier(nullHostnameVerifier as HostnameVerifier)
//    }
//
//    def static generarPasswordUsuario(){
//        String pass = ""
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(1, true, false).toLowerCase()
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(1, true, false).toUpperCase()
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(2, false, true)
//        int moduloHoraActual = System.currentTimeMillis() % 3
//        if(moduloHoraActual == 0) {
//            pass = pass + "!"
//        }
//        else {
//            if(moduloHoraActual == 1) {
//                pass = pass + "%"
//            }
//            else {
//                pass = pass + "*"
//            }
//        }
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(1, true, false).toUpperCase()
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(1, true, false).toLowerCase()
//        pass = pass + org.apache.commons.lang.RandomStringUtils.random(2, false, true)
//        return pass
//    }
//
//    public static String obtenerEntornoActual(){
//        if (grails.util.Environment.current == grails.util.Environment.PRODUCTION) {
//            return "prod"
//        }
//        else {
//            return "dev"
//        }
//    }
//
//    def static incrementarLetra(String letraActual){
//        if(letraActual== "Z"){
//            return "A"
//        }
//        int charValue = letraActual.charAt(0);
//        String next = String.valueOf( (char) (charValue + 1));
//        return next
//    }
//
//    def static String obtenerURLImagenAcceso(String imagenLocal){
//        String urlImagen = ""
//        if(grails.util.Holders.config.acceso.imagen.uri && grails.util.Holders.config.acceso.imagen.uri != '') {
//            urlImagen = grails.util.Holders.config.acceso.imagen.uri
//            //logger.error("Imprimir historial laboral - urlImagen (del properties): " + urlImagen)
//        }
//        else {
//            urlImagen = grails.util.Holders.config.grails.serverURLInterna + imagenLocal
//            //logger.error("Imprimir historial laboral - urlImagen (logoAccesoForm.png): " + urlImagen)
//        }
//        urlImagen = urlImagen.replace("jpcloud//jpcloud", "jpcloud") //correccion, assentpath añade el /jpcloud, y el severURLInterna también
//        urlImagen = urlImagen.replace("jpcloud/jpcloud", "jpcloud") //correccion, assentpath añade el /jpcloud, y el severURLInterna también
//        logger.info("obtenerURLImagenAcceso - urlImagen: " + urlImagen)
//        return urlImagen
//    }
//
//    def static long obtenerIdCuentaProduccion(){
//        if(grails.util.Holders.config.cuentaProduccionId!=''){
//            String numero = grails.util.Holders.config.cuentaProduccionId
//            if(numero.isNumber()){
//                return numero as long
//            }
//        }
//        return 1
//    }
//
//    def static ArrayList dividirArrayList(ArrayList original, int maxElementos){
//        ArrayList salida = new ArrayList()
//        int numeroActual = 0
//        ArrayList arrayDivididoTemporal = null
//        for(int i=0;i<original.size();i++){
//            if(arrayDivididoTemporal == null){
//                arrayDivididoTemporal = new ArrayList()
//                numeroActual = 0
//            }
//            arrayDivididoTemporal.add(original[i])
//            numeroActual++
//            if(numeroActual == maxElementos || i == (original.size()-1)){
//                if(arrayDivididoTemporal.size()>0){
//                    salida.add(arrayDivididoTemporal)
//                }
//                arrayDivididoTemporal = null
//                numeroActual=0
//            }
//        }
//        return salida
//    }
//
//    def static String reemplazarEspaciosEnBlanco(String cadena){
//        // reemplaza desde 2 hasta 15 espacios en blanco en una cadena de texto
//        //y trim final
//        return cadena
//                .replace("               ", " ")
//                .replace("              ", " ")
//                .replace("             ", " ")
//                .replace("            ", " ")
//                .replace("           ", " ")
//                .replace("          ", " ")
//                .replace("         ", " ")
//                .replace("        ", " ")
//                .replace("       ",  " ")
//                .replace("      ",   " ")
//                .replace("     ",    " ")
//                .replace("    ",     " ")
//                .replace("   ",      " ")
//                .replace("  ",       " ")
//                .replaceAll("&"+"nbsp;", " ")
//                .replaceAll("&"+"#160;", " ")
//                .trim()
//    }
}
