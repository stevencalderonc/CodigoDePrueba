package demo.app

import grails.testing.mixin.integration.Integration
import grails.gorm.transactions.Rollback
import spock.lang.Specification
import org.hibernate.SessionFactory

@Integration
@Rollback
class UsuarioProductoServiceSpec extends Specification {

    UsuarioProductoService usuarioProductoService
    SessionFactory sessionFactory

    private Long setupData() {
        // TODO: Populate valid domain instances and return a valid ID
        //new UsuarioProducto(...).save(flush: true, failOnError: true)
        //new UsuarioProducto(...).save(flush: true, failOnError: true)
        //UsuarioProducto usuarioProducto = new UsuarioProducto(...).save(flush: true, failOnError: true)
        //new UsuarioProducto(...).save(flush: true, failOnError: true)
        //new UsuarioProducto(...).save(flush: true, failOnError: true)
        assert false, "TODO: Provide a setupData() implementation for this generated test suite"
        //usuarioProducto.id
    }

    void "test get"() {
        setupData()

        expect:
        usuarioProductoService.get(1) != null
    }

    void "test list"() {
        setupData()

        when:
        List<UsuarioProducto> usuarioProductoList = usuarioProductoService.list(max: 2, offset: 2)

        then:
        usuarioProductoList.size() == 2
        assert false, "TODO: Verify the correct instances are returned"
    }

    void "test count"() {
        setupData()

        expect:
        usuarioProductoService.count() == 5
    }

    void "test delete"() {
        Long usuarioProductoId = setupData()

        expect:
        usuarioProductoService.count() == 5

        when:
        usuarioProductoService.delete(usuarioProductoId)
        sessionFactory.currentSession.flush()

        then:
        usuarioProductoService.count() == 4
    }

    void "test save"() {
        when:
        assert false, "TODO: Provide a valid instance to save"
        UsuarioProducto usuarioProducto = new UsuarioProducto()
        usuarioProductoService.save(usuarioProducto)

        then:
        usuarioProducto.id != null
    }
}
