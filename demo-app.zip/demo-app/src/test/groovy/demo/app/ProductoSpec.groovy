package demo.app

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ProductoSpec extends Specification implements DomainUnitTest<Producto> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
