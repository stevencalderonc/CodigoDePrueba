package demo.app

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class UsuarioProductoControllerSpec extends Specification implements ControllerUnitTest<UsuarioProductoController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
