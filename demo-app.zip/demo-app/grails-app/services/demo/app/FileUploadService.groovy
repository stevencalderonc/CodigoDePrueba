package com.kdcm

/*
import com.drew.imaging.ImageMetadataReader
import com.drew.lang.GeoLocation
import com.drew.metadata.Directory
import com.drew.metadata.exif.ExifDirectoryBase
import com.drew.metadata.exif.ExifIFD0Directory
import com.drew.metadata.exif.GpsDirectory
import com.jpicadoyasociados.MultipartImage
import com.jpicadoyasociados.seguridad.Usuario
import org.springframework.web.multipart.MultipartFile
import org.imgscalr.Scalr
import javax.annotation.PreDestroy
import java.awt.image.BufferedImage
import javax.imageio.ImageIO
import org.apache.commons.logging.LogFactory
import java.awt.image.ColorConvertOp
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors;
import java.util.Calendar;
 */

//@Transactional
class FileUploadService {

    boolean transactional = false

//    private static final logger = LogFactory.getLog(this)
//
//    static final numeroIntentos = 3 //intentos para reobtener el archivo de la base de datos y del sistema de ficheros
//
//    ExecutorService executor = Executors.newSingleThreadExecutor()
//    //ExecutorService executor = Executors.newFixedThreadPool(10)
//    def messageSource
//
//    @PreDestroy
//    void shutdown() {
//        executor.shutdownNow()
//    }

    def usuarioService
    def grailsApplication

    //String formatName = "png"
    String formatName = "jpg"

//    String obtenerRutaAbsolutaMultimedia() {
////		def grailsApplication = new com.jpicadoyasociados.seguridad.Usuario().domainClass.grailsApplication
////		def config = grailsApplication.config
////		return config.multimedia.root.dir
//        //return usuarioService.obtenerGrailsApplicationPropiedad('multimedia.root.dir')
//        return grailsApplication.config.multimedia.root.dir
//    }
//
//    public crearDirectorio(String storagePath) {
//        // Create storage path directory if it does not exist
//        def storagePathDirectory = new File(storagePath)
//        if (!storagePathDirectory.exists()) {
//            //print "CREATING DIRECTORY ${storagePath}: "
//            if (storagePathDirectory.mkdirs()) {
//                //println "SUCCESS"
//            } else {
//                //println "FAILED"
//                logger.error("Error creando directorio: " + storagePath)
//            }
//        }
//    }
//
//    public vaciarDirectorioTemporal(){
//        String path = obtenerRutaAbsolutaMultimedia() + "tmp/"
//        File[] flist = new File(path).listFiles()
//        if (flist != null && flist.length > 0) {
//            for (File f : flist) {
//                if(f.isDirectory()){
//                    if(!f.deleteDir()){
//                        logger.error("Error eliminado directorio de temporales: " + f.path)
//                    }
//                }
//                else {
//                    if (!borrarArchivo(f)) {
//                        logger.error("Error eliminado archivo del directorio de temporales: " + f.path)
//                    }
//                }
//            }
//        }
//    }
//
//    public vaciarDirectorioTemporalEnvioEvaluaciones(){
//        String path = obtenerRutaAbsolutaMultimedia() + "tempEnvioEvaluaciones/"
//        File[] flist = new File(path).listFiles()
//        if (flist != null && flist.length > 0) {
//            for (File f : flist) {
//                if(f.isDirectory()){
//
//                    String nombreDirectorio = f.name
//                    String fechaStr = nombreDirectorio.split("_")[2]
//
//                    Date fArchivo = new Date()
//
//                    String day
//                    String month
//                    String year
//
//                    year = fechaStr.substring(0,4)
//                    month = fechaStr.substring(4,6)
//                    day = fechaStr.substring(6,8)
//
//                    fArchivo.set(year:Integer.parseInt(year), month:Integer.parseInt(month)-1, dayOfMonth: Integer.parseInt(day))
//
//                    Calendar fechaActual = Calendar.getInstance()
//                    fechaActual.setTime(new Date())
//
//                    Calendar fechaDelArchivo = Calendar.getInstance()
//                    fechaDelArchivo.setTime(fArchivo)
//
//                    fechaActual.add(Calendar.DATE, -14)
//
//                    if(fechaActual >= fechaDelArchivo){
//                        // se borra si tiene 2 semanas o más de antiguedad
//                        if(!f.deleteDir()){
//                            logger.error("Error eliminado directorio de evaluaciones ZIP temporales: " + f.path)
//                        }
//                    }
//
//                }
//                else {
//                    if (!borrarArchivo(f)) {
//                        logger.error("Error eliminado archivo del directorio de evaluaciones ZIP temporales: " + f.path)
//                    }
//                }
//            }
//        }
//    }
//
//    private BufferedImage escalarImagen(BufferedImage bufferedImage, int maxWidthImagen, int maxHeightImagen) {
//        BufferedImage scaledImage  = bufferedImage
//        if (bufferedImage.getWidth() > maxWidthImagen) {
//            //println "SE ESCALA LA IMAGEN POR EL ANCHO"
//            def methodScalr = Scalr.Method.AUTOMATIC
//            if(maxWidthImagen <= 800) {
//                methodScalr = Scalr.Method.QUALITY
//            }
//            //scaledImage = Scalr.resize(bufferedImage, Scalr.Method.BALANCED, Scalr.Mode.FIT_TO_WIDTH, maxWidthImagen, maxHeightImagen, Scalr.OP_ANTIALIAS);
//            scaledImage = Scalr.resize(bufferedImage, methodScalr, Scalr.Mode.FIT_TO_WIDTH, maxWidthImagen, maxHeightImagen, Scalr.OP_ANTIALIAS);
//        }
//
//        if (bufferedImage.getHeight() > maxHeightImagen) {
//            //println "SE ESCALA LA IMAGEN POR EL ALTO"
//            def methodScalr = Scalr.Method.AUTOMATIC
//            if(maxHeightImagen <= 800) {
//                methodScalr = Scalr.Method.QUALITY
//            }
//            //scaledImage = Scalr.resize(bufferedImage, Scalr.Method.BALANCED, Scalr.Mode.FIT_TO_HEIGHT, maxWidthImagen, maxHeightImagen, Scalr.OP_ANTIALIAS);
//            scaledImage = Scalr.resize(bufferedImage, methodScalr, Scalr.Mode.FIT_TO_HEIGHT, maxWidthImagen, maxHeightImagen, Scalr.OP_ANTIALIAS);
//        }
//        return scaledImage
//    }
//
//    private File convert(MultipartFile file) {
//        crearDirectorio(obtenerRutaAbsolutaMultimedia() + "tmp/")
//        File convFile = new File(obtenerRutaAbsolutaMultimedia() + "tmp/" + file.getOriginalFilename());
//        convFile.createNewFile();
//        FileOutputStream fos = new FileOutputStream(convFile);
//        fos.write(file.getBytes());
//        fos.close();
//        return convFile;
//    }
//
//    private optimizarPng(String ruta) {
//        //Si se guarda un png se optimiza para que ocupe menos espacio
//        executor.execute {
//            //Se ejecuta en nuevos hilos, asi el usuario no lo nota, y se va haciendo casi en tiempo real
//            def timeStampInicial = System.currentTimeMillis()
//
//            final InputStream imageIS = new BufferedInputStream(new FileInputStream(ruta));
//            final com.googlecode.pngtastic.core.PngImage image = new com.googlecode.pngtastic.core.PngImage(imageIS);
//
//            // optimize
//            final com.googlecode.pngtastic.core.PngOptimizer optimizer = new com.googlecode.pngtastic.core.PngOptimizer();
//            final com.googlecode.pngtastic.core.PngImage optimizedImage = optimizer.optimize(image);
//
//            // export the optimized image to a new file
//            final ByteArrayOutputStream optimizedBytes = new ByteArrayOutputStream();
//            optimizedImage.writeDataOutputStream(optimizedBytes);
//            optimizedImage.export(ruta, optimizedBytes.toByteArray());
//            imageIS.close()
//            def timeStampFinal = System.currentTimeMillis()
//            logger.info("-- optimizarPng("+ ruta +") duracion: " + ((timeStampFinal - timeStampInicial) / 1000) + " segundos")
//        }
//    }
//
//    private obtenerTamanoImagenes(String ruta) {
//
//    }
//
//    public String limpiarNombreArchivo(String nombre){
//        // se cambia \, /, :, *, ¿, ?. <, >, | por _
//        //return nombre.replace("\\", "_").replace("/", "_").replace(":", "_").replace("*", "_").replace("¿", "_").replace("?", "_").replace("\"", "_").replace("<", "_").replace(">", "_").replace("|", "_")
//        //No, se utiliza esta expresion regular, explicación:
//        //[a-zA-Z0-9\\._] matches a letter from a-z lower or uppercase, numbers, dots and underscores
//        //[^a-zA-Z0-9\\._] is the inverse. i.e. all characters which do not match the first expression
//        //[^a-zA-Z0-9\\._]+ is a sequence of characters which do not match the first expression
//        //se añade guion como permitido - y menos -
//        return nombre.replaceAll("[^a-zA-Z0-9\\._-]+", "_");
//    }
//
//    //guarda la imagen, primero la redimensiona
//    int uploadImagenEscalada(MultipartFile file, String name, String destinationDirectory, MultimediaImagen imagen) {
//        logger.info("uploadImagenEscalada() - name: " + name)
//        name = limpiarNombreArchivo(name)
//        logger.info("uploadImagenEscalada() - name: " + name)
//        //println "uploadImagenEscalada()"
//        final int maxWidthImagenGrande = 5120 // 2560 // 1280 //1024 //800
//        final int maxHeightImagenGrande = 3840 // 1920 // 960 // 768 //600
//        final int maxWidthImagenMed = 800 //400
//        final int maxHeightImagenMed = 600 //300
//        final int maxWidthImagenPeq = 400 //200
//        final int maxHeightImagenPeq = 300 // 150
//        final int maxWidthImagenMuyPeq = 200 // 100
//        final int maxHeightImagenMuyPeq = 150 //75
//        final int maxWidthImagenMuyMuyPeq = 100 // 50
//        final int maxHeightImagenMuyMuyPeq = 100 // 50
//
//        def directorioRoot = obtenerRutaAbsolutaMultimedia()
//
//        // Store file
//        if (!file.isEmpty()) {
//            String nombreOriginal = file.getOriginalFilename()
//            logger.info("-- nombreOriginal: " + nombreOriginal)
//            logger.info("-- file.getSize(): " + file.getSize())
//
//            String extension = nombreOriginal.substring(nombreOriginal.lastIndexOf(".") + 1)
//            // logger.info("-- extension: " + extension)
//            nombreOriginal = nombreOriginal.substring(0,nombreOriginal.lastIndexOf("."))
//            // logger.info("-- nombreOriginal: " + nombreOriginal)
//            nombreOriginal = nombreOriginal.replace(".", "")
//            // logger.info("-- nombreOriginal: " + nombreOriginal)
//            //Se escala la imagen (solo si supera el ancho o alto maximo):
//            InputStream inputStream = file.getInputStream();
//            BufferedImage bufferedImage = ImageIO.read(inputStream);
//            inputStream.close()
//
//            File fileTmp
//            Date fechaOriginal = null
//            double lat = 0.0;
//            double lng = 0.0;
//            String fabricante = ""
//            String modelo = ""
//            try {
//                logger.info("org.hibernate.Hibernate.getClass(file).simpleName: " + org.hibernate.Hibernate.getClass(file).simpleName)
//                fileTmp = convert(file)
//                com.drew.metadata.Metadata metadata = ImageMetadataReader.readMetadata(fileTmp);
//                Directory directory = metadata.getFirstDirectoryOfType(ExifIFD0Directory.class);
//                if(directory != null || org.hibernate.Hibernate.getClass(file).simpleName == 'MultipartImage') {
//                    int orientation = 1;
//                    try {
//                        if(org.hibernate.Hibernate.getClass(file).simpleName == 'MultipartImage'){
//                            orientation = ((MultipartImage)file).orientation
//                        }
//                        else {
//                            orientation = directory.getInt(ExifIFD0Directory.TAG_ORIENTATION);
//                        }
//                    } catch (Exception me) {
//                        logger.info("excepcion: " + me.message)
//                        log.warn("No se puede obtener orientacion");
//                    }
//                    logger.info("--orientation: " + orientation)
//                    switch (orientation) {
//                        case 1: // [Exif IFD0] Orientation - Top, left side (Horizontal / normal)
//                            //nada que hacer
//                            break
//                        case 49:
//                            // Igual que el 1 (parece que el código cuando se lee desde javascript es este
//                            //nada que hacer
//                            break
//                        case 6: // [Exif IFD0] Orientation - Right side, top (Rotate 90 CW)
//                            logger.info("rotando imagen 90 grados")
//                            bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_90)
//                            break
//                        case 54: // Igual que el 6 (parece que el código cuando se lee desde javascript es este
//                            //2020-06-12 PARECE QUE ESTO YA NO HACE FALTA
//                            //logger.info("rotando imagen 90 grados")
//                            //bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_90)
//                            break
//                        case 3: // [Exif IFD0] Orientation - Bottom, right side (Rotate 180)
//                            logger.info("rotando imagen 180 grados")
//                            bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_180)
//                            break
//                        case 51: // Igual que el 3 (parece que el código cuando se lee desde javascript es este
//                            //2020-06-12 PARECE QUE ESTO YA NO HACE FALTA
//                            //logger.info("rotando imagen 180 grados")
//                            //bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_180)
//                            break
//                        case 8: // [Exif IFD0] Orientation - Left side, bottom (Rotate 270 CW)
//                            logger.info("rotando imagen 270 grados")
//                            bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_270)
//                            break
//                        case 56: // Igual que el 8 (parece que el código cuando se lee desde javascript es este
//                            //2020-06-12 PARECE QUE ESTO YA NO HACE FALTA
//                            //logger.info("rotando imagen 270 grados")
//                            //bufferedImage = Scalr.rotate(bufferedImage, Scalr.Rotation.CW_270)
//                            break
//                    }
//
//                    try {
//                        if(org.hibernate.Hibernate.getClass(file).simpleName == 'MultipartImage'){
//                            imagen.fechaImagen = ((MultipartImage)file).dateTimeOriginal
//                            if(imagen.fechaImagen==null){
//                                imagen.fechaImagen = ((MultipartImage)file).dateTime
//                            }
//                        }
//                        else {
//                            fechaOriginal = directory.getDate(ExifDirectoryBase.TAG_DATETIME_ORIGINAL)
//                            logger.info("------- fechaOriginal 1: " + fechaOriginal)
//                            if(fechaOriginal==null) {
//                                fechaOriginal = directory.getDate(ExifDirectoryBase.TAG_DATETIME)
//                                logger.info("------- fechaOriginal 2: " + fechaOriginal)
//                            }
//
//                            use(groovy.time.TimeCategory) {
//                                //Esto es una ñapa para ajustar la hora a la costarricense bien
//                                fechaOriginal = fechaOriginal + 6.hours
//                            }
//
//                            logger.info("------- fechaOriginal 3: " + fechaOriginal)
//                            imagen.fechaImagen = fechaOriginal
//                        }
//                    }
//                    catch (Exception me) {
//                        log.warn("No se puede obtener fecha original");
//                    }
//
//                    try {
//                        if(org.hibernate.Hibernate.getClass(file).simpleName == 'MultipartImage'){
//                            logger.info("-- leyendo marca y modelo de la imagen reducida")
//                            fabricante = ((MultipartImage)file).make
//                            modelo = ((MultipartImage)file).model
//                        }
//                        else {
//                            logger.info("-- leyendo marca y modelo de la imagen original")
//                            fabricante = directory.getString(ExifIFD0Directory.TAG_MAKE)
//                            modelo = directory.getString(ExifIFD0Directory.TAG_MODEL)
//                        }
//
//                        imagen.camaraModelo = modelo
//                        imagen.camaraFabricante = fabricante
//                        logger.info("------- fabricante: " + fabricante)
//                        logger.info("------- modelo: " + modelo)
//                    }
//                    catch (Exception me) {
//                        log.warn("No se puede obtener fecha original");
//                    }
//                }
//                try {
//                    if(org.hibernate.Hibernate.getClass(file).simpleName == 'MultipartImage'){
//                        lat = Double.parseDouble(((MultipartImage)file).latitude);
//                        lng = Double.parseDouble(((MultipartImage)file).longitude);
//                    }
//                    else {
//                        GpsDirectory gpsDirectory = metadata.getFirstDirectoryOfType(GpsDirectory.class);
//                        if(gpsDirectory) {
//                            GeoLocation location = gpsDirectory.getGeoLocation();
//                            lat = location.getLatitude();
//                            lng = location.getLongitude();
//                        }
//                    }
//                    logger.info("------- lat: " + lat)
//                    logger.info("------- lng: " + lng)
//                    imagen.latitude = lat
//                    imagen.longitude = lng
//                }
//                catch (Exception me) {
//                    log.warn("No se puede obtener longitud y latitud");
//                    logger.info("Exc: " + me.message)
//                }
//
//                /*for (Directory directorio : metadata.getDirectories()) {
//                    for (Tag tag : directorio.getTags()) {
//                         logger.info("Directorio: " + directorio.getName() + " - tag: " + tag.getTagName() + " tag descripcion: " + tag.getDescription())
//                    }
//                    if (directorio.hasErrors()) {
//                        for (String error : directorio.getErrors()) {
//                            System.err.format("ERROR: %s", error);
//                        }
//                    }
//                }*/
//
//                fileTmp.delete()
//            }
//            catch (Exception e) {
//                logger.error("Error comprando si se debe rotar una imagen")
//                logger.error(e.toString())
//                logger.error(e.printStackTrace())
//            }
//            finally {
//                fileTmp.delete()
//            }
//
//            //Fin orientación de la imagen
//
//            //Imagenes escaladas
//            BufferedImage scaledImageGrande = escalarImagen(bufferedImage,maxWidthImagenGrande, maxHeightImagenGrande)
//            BufferedImage scaledImageMed = escalarImagen(bufferedImage,maxWidthImagenMed, maxHeightImagenMed)
//            BufferedImage scaledImagePeq = escalarImagen(bufferedImage,maxWidthImagenPeq, maxHeightImagenPeq)
//            BufferedImage scaledImageMuyPeq = escalarImagen(bufferedImage,maxWidthImagenMuyPeq, maxHeightImagenMuyPeq)
//            BufferedImage scaledImageMuyMuyPeq = escalarImagen(bufferedImage,maxWidthImagenMuyMuyPeq, maxHeightImagenMuyMuyPeq)
//
//            //Guardar las imágenes
//            def storagePath = directorioRoot + destinationDirectory
//            crearDirectorio(storagePath)
//            def nombre = name.split("\\.")[0]
//            //def extension = name.split("\\.")[1]
//            //def nombreOriginalNombre = nombreOriginal.split("\\.")[0]
//            //nombreOriginalNombre = nombreOriginalNombre.replace(" ", "_")
//            //def extension = nombreOriginal.split("\\.")[1]
//
//            String format= "jpg"
//            if(extension.toLowerCase() == "png") {
//                format = "png"
//            }
//
//            File outputfileMuyMuyPeq = new File("${storagePath}${nombre}_${nombreOriginal}_muymuypeq.${extension}");
//            try {
//                ImageIO.write(scaledImageMuyMuyPeq, format, outputfileMuyMuyPeq);
//            }
//            catch (javax.imageio.IIOException e){
//                BufferedImage rgbImage = new BufferedImage(scaledImageMuyMuyPeq.getWidth(),
//                        scaledImageMuyMuyPeq.getHeight(), BufferedImage.TYPE_INT_RGB);
//                ColorConvertOp op = new ColorConvertOp(null);
//                op.filter(scaledImageMuyMuyPeq, rgbImage);
//                ImageIO.write(rgbImage, "JPEG", outputfileMuyMuyPeq);
//            }
//            if(format=="png") {
//                optimizarPng(outputfileMuyMuyPeq.path)
//            }
//
//            File outputfileMuyPeq = new File("${storagePath}${nombre}_${nombreOriginal}_muypeq.${extension}");
//            try {
//                ImageIO.write(scaledImageMuyPeq, format, outputfileMuyPeq);
//            }
//            catch (javax.imageio.IIOException e){
//                BufferedImage rgbImage = new BufferedImage(scaledImageMuyPeq.getWidth(),
//                        scaledImageMuyPeq.getHeight(), BufferedImage.TYPE_INT_RGB);
//                ColorConvertOp op = new ColorConvertOp(null);
//                op.filter(scaledImageMuyPeq, rgbImage);
//                ImageIO.write(rgbImage, "JPEG", outputfileMuyPeq);
//            }
//            if(format=="png") {
//                optimizarPng(outputfileMuyPeq.path)
//            }
//
//            File outputfilePeq = new File("${storagePath}${nombre}_${nombreOriginal}_peq.${extension}");
//            try {
//                ImageIO.write(scaledImagePeq, format, outputfilePeq);
//            }
//            catch (javax.imageio.IIOException e){
//                BufferedImage rgbImage = new BufferedImage(scaledImagePeq.getWidth(),
//                        scaledImagePeq.getHeight(), BufferedImage.TYPE_INT_RGB);
//                ColorConvertOp op = new ColorConvertOp(null);
//                op.filter(scaledImagePeq, rgbImage);
//                ImageIO.write(rgbImage, "JPEG", outputfilePeq);
//            }
//            if(format=="png") {
//                optimizarPng(outputfilePeq.path)
//            }
//
//            File outputfileMed = new File("${storagePath}${nombre}_${nombreOriginal}_med.${extension}");
//            try {
//                ImageIO.write(scaledImageMed, format, outputfileMed);
//            }
//            catch (javax.imageio.IIOException e){
//                BufferedImage rgbImage = new BufferedImage(scaledImageMed.getWidth(),
//                        scaledImageMed.getHeight(), BufferedImage.TYPE_INT_RGB);
//                ColorConvertOp op = new ColorConvertOp(null);
//                op.filter(scaledImageMed, rgbImage);
//                ImageIO.write(rgbImage, "JPEG", outputfileMed);
//            }
//            if(format=="png") {
//                optimizarPng(outputfileMed.path)
//            }
//
//            File outputfileGrande = new File("${storagePath}${nombre}_${nombreOriginal}.${extension}");
//            try {
//                ImageIO.write(scaledImageGrande, format, outputfileGrande);
//            }
//            catch (javax.imageio.IIOException e){
//                BufferedImage rgbImage = new BufferedImage(scaledImageGrande.getWidth(),
//                        scaledImageGrande.getHeight(), BufferedImage.TYPE_INT_RGB);
//                ColorConvertOp op = new ColorConvertOp(null);
//                op.filter(scaledImageGrande, rgbImage);
//                ImageIO.write(rgbImage, "JPEG", outputfileGrande);
//            }
//            if(format=="png") {
//                optimizarPng(outputfileGrande.path)
//            }
//
//            imagen.imagen = "${nombre}_${nombreOriginal}.${extension}"
//
//            logger.info("-- hanciendo flus en las bufferedImage de la carga de fotografias ")
//            scaledImageGrande.flush()
//            scaledImageMed.flush()
//            scaledImagePeq.flush()
//            scaledImageMuyPeq.flush()
//            scaledImageMuyMuyPeq.flush()
//
////			File outputfileOriginal = new File("${storagePath}${nombre}_original.${extension}");
////			ImageIO.write(bufferedImage, "png", outputfileOriginal);
//
//            return (outputfileGrande.size() + outputfileMed.size() + outputfilePeq.size() + outputfileMuyPeq.size() + outputfileMuyMuyPeq.size()) / 1000.0
//            //return (outputfileGrande.size() + outputfileMed.size() + outputfilePeq.size() + outputfileOriginal.size()) / 1000.0
//            //return "${name}"
//        } else {
//            //println "File ${file.inspect()} was empty!"
//            return 0
//        }
//    }
//
//    //guarda el fichero (se puede utilizar para imágenes pero no las va redimiensionar)
//    String uploadFile(MultipartFile file, String name, String destinationDirectory) {
//        logger.info("uploadFile() - file: " + file.toString() + " - name: " + name + " - destinationDirectory: " + destinationDirectory )
//        name = limpiarNombreArchivo(name)
//        logger.info("uploadFile() - name: " + name + ")")
//        def directorioRoot = obtenerRutaAbsolutaMultimedia()
//        def storagePath = directorioRoot + destinationDirectory
//        crearDirectorio(storagePath)
//        // Store file
//        if (!file.isEmpty()) {
//            String extension = name.substring(name.lastIndexOf(".") + 1)
//            file.transferTo(new File("${storagePath}/${name}"))
//            //println "Saved file: ${storagePath}${name}"
//            //return "${storagePath}/${name}"
//            return "${name}"
//        } else {
//            logger.error("File ${file.inspect()} was empty!")
//            return null
//        }
//    }
//
//    boolean removeImagenEscalada(String file, String destinationDirectory) {
//        def directorioRoot = obtenerRutaAbsolutaMultimedia()
//        def storagePath = directorioRoot + destinationDirectory
//        def nombre = file.split("\\.")[0]
//        def extension = file.split("\\.")[1]
//        //println "Eliminando fichero: " + storagePath + file
//        boolean fileSuccessfullyDeleted //=  new File(storagePath + nombre + "." + extension).delete()
//        //Se borran todaas las versiones de la imagen subidas:
//        fileSuccessfullyDeleted = borrarArchivo(new File(storagePath + nombre + "." + extension))
//        fileSuccessfullyDeleted = fileSuccessfullyDeleted && borrarArchivo(new File(storagePath + nombre + "_med." + extension))
//        fileSuccessfullyDeleted = fileSuccessfullyDeleted && borrarArchivo(new File(storagePath + nombre + "_peq." + extension))
//        fileSuccessfullyDeleted = fileSuccessfullyDeleted && borrarArchivo(new File(storagePath + nombre + "_muypeq." + extension))
//        fileSuccessfullyDeleted = fileSuccessfullyDeleted && borrarArchivo(new File(storagePath + nombre + "_muymuypeq." + extension))
//        //fileSuccessfullyDeleted = fileSuccessfullyDeleted && borrarArchivo(new File(storagePath + nombre + "_original." + extension))
//
//        //println "Fichero eliminado: " + fileSuccessfullyDeleted
//        return fileSuccessfullyDeleted
//    }
//
//    private boolean borrarArchivo(File archivo) {
//        //println "borrando: " + archivo
//        if (archivo.exists()) {
//            return archivo.delete()
//        }
//        else {
//            logger.error("Intentanto borrar archivo que no existe (se considera borrado): " + archivo)
//            return true //si el archivo no existe se considera borrado
//        }
//    }
//
//    boolean removeFile(String file, String destinationDirectory) {
//        logger.info("removeFile")
//        def directorioRoot = obtenerRutaAbsolutaMultimedia()
//        def storagePath = directorioRoot + destinationDirectory
//        //println "Eliminando fichero: " + storagePath + file
//        boolean fileSuccessfullyDeleted = false
//
//        executor.execute {
//            int numeroIntentos = 0
//            boolean enviado = false
//            while(!fileSuccessfullyDeleted && numeroIntentos < 5){
//                try {
//                    logger.info("**** eliminado archivo " + storagePath + file)
//                    fileSuccessfullyDeleted = borrarArchivo(new File(storagePath + file))
//                }
//                catch (Exception e) {
//                    logger.error("Error enviando email: (intento: "+ numeroIntentos + ") " + e.message)
//                    numeroIntentos+=1
//                    sleep(5000) //se pone una pausa (muchas veces el error es por conexion, mejor esperar un poco)
//                }
//            }
//
//            if(!fileSuccessfullyDeleted) {
//                logger.error("NO SE HA BORRADO EL FICHERO: " + storagePath + file)
//            }
//        }
//
//        return true
//    }
//
//    String validarImagen(MultipartFile file) {
//        return validarImagen(file, 0)
//    }
//
//    String validarImagen(MultipartFile file, int sizeMax) {
//        //sizeMax en KB
//        String validacion = ""
//        String contentType = file.getContentType();
//        //println "contentType: " + contentType
//        if (contentType!="image/jpeg" && contentType!="image/png") {
//            validacion = validacion + " Formato de imagen incorrecto (sólo se admiten .jpg , .jpeg o .png)"
//        }
//
//        if (sizeMax>0) { //sólo si el parámetro es mayor a 0
//            double tamano = file.size
//            tamano = ((tamano / 1024) as double).round() //para pasarlo a KB
//            //println "tamano: " + tamano
//
////			if (sizeMax == 0) {
////				sizeMax = 512 // 512KB
////			}
////
//            if (tamano > sizeMax) {
//                validacion = validacion + " Tamaño de la imagen supera el máximo permitido ("+ sizeMax +"KB)"
//            }
//        }
//
//        if (validacion != "") {
//            validacion = "¡Error validación imagen: " + validacion + "!"
//        }
//        return validacion
//    }
//
//    String validarDocumentoExterno(MultipartFile file, int sizeMax) {
//        logger.info("validarDocumentoExterno - sizeMax: " + sizeMax)
//        //sizeMax en KB
//        String validacion = ""
//        String contentType = file.getContentType();
//        logger.info("validarDocumentoExterno() - contentType: " + contentType)
//        //println "contentType: " + contentType
//        ArrayList contentTypesPermitidos = FileUploadService.obtenerContentTypesPermitidosExterno()
//        logger.info("validarDocumentoExterno() - contentTypesPermitidos.size(): " + contentTypesPermitidos.size())
//        logger.info("validarDocumentoExterno() - contentTypesPermitidos: " + contentTypesPermitidos)
//
//
//        if(!contentTypesPermitidos.contains(contentType)){
//            validacion = " Formato de documento incorrecto (" + contentType + ")."
//        }
//
//        double tamano = file.size
//        tamano = ((tamano / 1024) as double).round() //para pasarlo a KB
//        //println "tamano: " + tamano
//
//        //se lee el tamaño máximo desde la configuracion
//        sizeMax = obtenerSizeMaxExterno()
//        logger.info("validarDocumentoExterno() - sizeMax: " + sizeMax)
//
//        if (tamano > sizeMax) {
//            validacion = validacion + " Tamaño del documento supera el máximo permitido ("+ sizeMax +"KB)"
//        }
//
//        if (validacion != "") {
//            validacion = "¡Error validación documento externo: " + validacion + "!"
//        }
//        return validacion
//    }
//
//    String validarDocumento(MultipartFile file, int sizeMax) {
//        logger.info("validarDocumento - sizeMax: " + sizeMax)
//        //sizeMax en KB
//        String validacion = ""
//        String contentType = file.getContentType();
//        logger.info("validarDocumento() - contentType: " + contentType)
//        //println "contentType: " + contentType
//        ArrayList contentTypesPermitidos = FileUploadService.obtenerContentTypesPermitidos()
//        logger.info("validarDocumento() - contentTypesPermitidos.size(): " + contentTypesPermitidos.size())
//        logger.info("validarDocumento() - contentTypesPermitidos: " + contentTypesPermitidos)
//
//        if(!contentTypesPermitidos.contains(contentType)){
//            validacion = " Formato de documento incorrecto (" + contentType + ")."
//        }
//
//        double tamano = file.size
//        tamano = ((tamano / 1024) as double).round() //para pasarlo a KB
//        //println "tamano: " + tamano
//
//        //se lee el tamaño máximo desde la configuracion
//        sizeMax = obtenerSizeMax()
//        logger.info("validarDocumentoExterno() - sizeMax: " + sizeMax)
//
//        if (tamano > sizeMax) {
//            validacion = validacion + " Tamaño del documento supera el máximo permitido ("+ sizeMax +"KB)"
//        }
//
//        if (validacion != "") {
//            validacion = "¡Error validación documento: " + validacion + "!"
//        }
//        return validacion
//    }
//
//    public static int obtenerSizeMax(){
//        if(grails.util.Holders.config.documento.sizeMax==""){
//            return 51200 //50 MB
//        }
//        if(!grails.util.Holders.config.documento.sizeMax.isNumber()){
//            return 51200 //50 MB
//        }
//        return grails.util.Holders.config.documento.sizeMax as int
//    }
//
//    public static ArrayList obtenerContentTypesPermitidos(){
//        logger.info("obtenerContentTypesPermitidos() - contentTypes: " + grails.util.Holders.config.documento.contentTypes)
//        if(grails.util.Holders.config.documento.contentTypes==''){
//            return new ArrayList()
//        }
//        try {
//            String contentTypesPermitidosStr = grails.util.Holders.config.documento.contentTypes
//            contentTypesPermitidosStr = contentTypesPermitidosStr.replace(" ","")
//            logger.info("--- contentTypesPermitidosStr: " + contentTypesPermitidosStr)
//            ArrayList contentTypesPermitidos = contentTypesPermitidosStr.split(",")
//            logger.info("--- contentTypesPermitidos.size(): " + contentTypesPermitidos.size())
//            logger.info("--- contentTypesPermitidos: " + contentTypesPermitidos)
//            return contentTypesPermitidos
//        }
//        catch (e){
//            logger.error("obtenerContentTypesPermitidos() - e: " + e)
//            return new ArrayList()
//        }
//    }
//
//    public guardarBitacoraEliminacion(Multimedia multimedia){
//        logger.info("guardarBitacoraEliminacion() - multimedia.id: " + multimedia.id)
//        logger.info("guardarBitacoraEliminacion() - multimedia clase: " + org.hibernate.Hibernate.getClass(multimedia).simpleName)
//        Usuario usuarioActual = Usuario.usuarioActual()
//        def contenedor = multimedia.obtenerContenedor()
//        String contenedorClase = org.hibernate.Hibernate.getClass(contenedor).simpleName
//        String claseMessage = org.hibernate.Hibernate.getClass(contenedor).simpleName
//        String contenedorId = contenedor.id.toString()
//        String contenedorStr = contenedor.toString()
//        claseMessage = claseMessage.uncapitalize()
//        String controladorEnlace = claseMessage + "Controller"
//        String contenedorClaseNombre = messageSource.getMessage("${claseMessage}.label".toString(), null, "${claseMessage}".toString(), null)
//
//        MultimediaEliminacionBitacora.withNewSession {
//            MultimediaEliminacionBitacora multimediaEliminacionBitacora = new MultimediaEliminacionBitacora()
//            multimediaEliminacionBitacora.cuenta = multimedia.cuenta
//            multimediaEliminacionBitacora.numeroMultimedia = multimedia.numeroMultimedia
//            multimediaEliminacionBitacora.nombre = multimedia.nombre
//            multimediaEliminacionBitacora.tamanoKB = multimedia.tamanoKB
//            multimediaEliminacionBitacora.rutaFisicaRelativa = multimedia.rutaFisicaRelativa
//            multimediaEliminacionBitacora.rutaCompleta = multimedia.obtenerRutaCompleta()
//            multimediaEliminacionBitacora.contentType = multimedia.contentType
//            multimediaEliminacionBitacora.originalFileName = multimedia.originalFileName
//            multimediaEliminacionBitacora.extension = multimedia.extension
//            if (usuarioActual != null) {
//                multimediaEliminacionBitacora.usuario = usuarioActual
//            }
//            if(multimedia.usuarioSolicitudes){
//                multimediaEliminacionBitacora.usuarioSolicita = multimedia.usuarioSolicitudes
//            }
//            if(multimedia.motivoSolicitudes){
//                multimediaEliminacionBitacora.motivo = multimedia.motivoSolicitudes
//            }
//            multimediaEliminacionBitacora.contenedor = contenedorStr.take(2000)
//            multimediaEliminacionBitacora.contenedorId = contenedorId
//            multimediaEliminacionBitacora.contenedorClase = contenedorClase
//            multimediaEliminacionBitacora.contenedorClaseNombre = contenedorClaseNombre
//            multimediaEliminacionBitacora.contenedorController = controladorEnlace
//            multimediaEliminacionBitacora.save(flush: true, failOnError: true)
//        }
//    }

    /*
    public obtenerAtributos(Multimedia multimedia) { //no fucniona bien
        logger.info("obtenerAtributos: " + multimedia.id)
        //se hace en segundo plano
        def promiseObtenerAtributos = Promises.task {
            sleep(5000) //para que se haya guardado el archivo en el sistema de ficheros
            String rutaCompletaMultimedia = multimedia.obtenerRutaCompleta()
            logger.info("obtenerAtributos - rutaCompletaMultimedia: " + rutaCompletaMultimedia)
            int numeroIntentos = 0
            boolean guardado = false

            while(numeroIntentos<FileUploadService.numeroIntentos && guardado==false) {
                Multimedia.withTransaction {
                    File file = new File(rutaCompletaMultimedia)
                    try {
                        if (file.exists()) {
                            //se intenta leer los atributos del archivo
                            multimedia.tamanoKB = Math.round(file.size()/ 1024)
                            multimedia.originalFileName = file.getName().take(500)
                            multimedia.extension = FilenameUtils.getExtension(multimedia.originalFileName)
                            multimedia.contentType = Files.probeContentType(file.toPath())
                            try {
                                BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
                                DateFormat df=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
                                multimedia.creationTime = df.parse(df.format(attr.creationTime().toMillis()));
                                multimedia.lastModifiedTime = df.parse(df.format(attr.lastModifiedTime().toMillis()));
                                logger.info("obtenerAtributos() - multimedia.creationTime: " + multimedia.creationTime)
                                logger.info("obtenerAtributos() - multimedia.lastModifiedTime: " + multimedia.lastModifiedTime)
                            }
                            catch (Exception e) {
                                //si falla al leer estos atributos no se hace nada
                                logger.info("obtenerAtributos() - Exception leyendo creationTime y lastModifiedTime: " + e)
                                logger.info("obtenerAtributos() - Exception.message: " + e.message)
                                logger.info("obtenerAtributos() - Exception.printStackTrace: " + e.printStackTrace())
                            }
                            multimedia.attach()
                            //.attach()
                            multimedia.save(flush: true, failOnError: true)
                            guardado = true
                        } else {
                            numeroIntentos++
                            if(numeroIntentos == FileUploadService.numeroIntentos) {
                                logger.error("obtenerAtributos - intentando obtenerAtributos de archivo que no existe (multimedia id: ${multimedia.id}): ${rutaCompletaMultimedia}")
                            }
                            else {
                                logger.info("obtenerAtributos - intentando obtenerAtributos de archivo que no existe aún (multimedia id: ${multimedia.id}): ${rutaCompletaMultimedia}")
                                sleep(5000 * numeroIntentos)
                                //se vuelve a obtener el multimedia y su ruta
                                multimedia = Multimedia.createCriteria().get {
                                    createAlias("cuenta", "cu", org.hibernate.sql.JoinType.LEFT_OUTER_JOIN) //hace falta para que no de un error de lazy load al leer la cuenta
                                    eq("id", multimedia.id)
                                }
                                rutaCompletaMultimedia = multimedia.obtenerRutaCompleta()
                            }
                        }
                    }
                    catch (Exception e) {
                        numeroIntentos++ //para salir del while
                        logger.error("obtenerAtributos() - Exception: " + e)
                        logger.error("obtenerAtributos() - Exception.message: " + e.message)
                        logger.error("obtenerAtributos() - Exception.printStackTrace: " + e.printStackTrace())
                    }
                }
            }
        }
    }
     */
}