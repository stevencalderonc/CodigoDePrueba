package demo.app

import grails.gorm.services.Service

@Service(UsuarioProducto)
interface UsuarioProductoService {

    UsuarioProducto get(Serializable id)

    List<UsuarioProducto> list(Map args)

    Long count()

    void delete(Serializable id)

    UsuarioProducto save(UsuarioProducto usuarioProducto)

}