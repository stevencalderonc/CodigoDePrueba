package demo.app

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*
import org.hibernate.sql.JoinType
import org.apache.commons.logging.LogFactory

class UsuarioController {

    private static final logger = LogFactory.getLog(this)
    UsuarioService usuarioService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond usuarioService.list(params), model:[usuarioCount: usuarioService.count()]
    }

    def show(Long id) {
        respond usuarioService.get(id)
    }

    def create() {
        respond new Usuario(params)
    }

    def save(Usuario usuario) {
        if (usuario == null) {
            notFound()
            return
        }

        try {
            usuarioService.save(usuario)
        } catch (ValidationException e) {
            respond usuario.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'usuario.label', default: 'Usuario'), usuario.id])
                redirect usuario
            }
            '*' { respond usuario, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond usuarioService.get(id)
    }

    def update(Usuario usuario) {
        if (usuario == null) {
            notFound()
            return
        }

        try {
            usuarioService.save(usuario)
        } catch (ValidationException e) {
            respond usuario.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'usuario.label', default: 'Usuario'), usuario.id])
                redirect usuario
            }
            '*'{ respond usuario, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        usuarioService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'usuario.label', default: 'Usuario'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'usuario.label', default: 'Usuario'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }

    def productosAdquiridos(int id) {

        ArrayList<UsuarioProducto> lista = UsuarioProducto.createCriteria().list {
            eq("usuario.id", (int) id)
            projections {
                property "producto"
            }
            //createAlias("producto", "_producto", JoinType.INNER_JOIN)
            //createAlias("_producto.usuario", "_usuario", JoinType.INNER_JOIN)
        }
        // se retorna la siguiente view, con la lista resultante de hacer la consulta anterior...
        // projections filtró el resultado solo para 'Productos'
        respond lista, view:'productosAdquiridos'
    }


    def getById(int id){

        Usuario usuarioInstance = Usuario.findById(id)
        logger.info("user found: "  + usuarioInstance.nombre)
        respond usuarioInstance, view:'getById'
    }
}


// ejemplo de inner-join
/*
    def criteria = Spot.createCriteria()
    def result = criteria.list {
        eq("id", params.long("id"))
        createAlias('layoutSpot', 'lSpot', CriteriaSpecification.INNER_JOIN)
        createAlias('lSpot.sample', 'smpl', CriteriaSpecification.INNER_JOIN)
        projections {
            property "id"
            property "signal"
            property "block"
            property "row"
            property "col"
            property "smpl.name"
            property "smpl.type"
            property "smpl.target"
        }
        order('block', 'asc')
        order('row', 'desc')
        order('col', 'asc')
    }
*/