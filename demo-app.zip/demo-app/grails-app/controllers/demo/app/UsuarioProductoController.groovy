package demo.app

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class UsuarioProductoController {

    UsuarioProductoService usuarioProductoService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond usuarioProductoService.list(params), model:[usuarioProductoCount: usuarioProductoService.count()]
    }

    def show(Long id) {
        respond usuarioProductoService.get(id)
    }

    def create() {
        respond new UsuarioProducto(params)
    }

    def save(UsuarioProducto usuarioProducto) {
        if (usuarioProducto == null) {
            notFound()
            return
        }

        try {
            usuarioProductoService.save(usuarioProducto)
        } catch (ValidationException e) {
            respond usuarioProducto.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'usuarioProducto.label', default: 'UsuarioProducto'), usuarioProducto.id])
                redirect usuarioProducto
            }
            '*' { respond usuarioProducto, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond usuarioProductoService.get(id)
    }

    def update(UsuarioProducto usuarioProducto) {
        if (usuarioProducto == null) {
            notFound()
            return
        }

        try {
            usuarioProductoService.save(usuarioProducto)
        } catch (ValidationException e) {
            respond usuarioProducto.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'usuarioProducto.label', default: 'UsuarioProducto'), usuarioProducto.id])
                redirect usuarioProducto
            }
            '*'{ respond usuarioProducto, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        usuarioProductoService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'usuarioProducto.label', default: 'UsuarioProducto'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'usuarioProducto.label', default: 'UsuarioProducto'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }


}
