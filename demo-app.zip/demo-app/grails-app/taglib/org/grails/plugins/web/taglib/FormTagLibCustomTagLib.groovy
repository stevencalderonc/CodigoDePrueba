package org.grails.plugins.web.taglib

import org.apache.commons.logging.LogFactory
import org.grails.core.artefact.DomainClassArtefactHandler
import org.springframework.context.MessageSourceResolvable
import org.springframework.web.servlet.support.RequestContextUtils

import java.text.DateFormat
import java.text.DateFormatSymbols

class FormTagLibCustomTagLib  extends FormTagLib {
    //static defaultEncodeAs = [taglib:'html']
    static encodeAsForTags = [tagName: [taglib:'html'], otherTagName: [taglib:'none']]

    private static final logger = LogFactory.getLog(this)

    static namespace = "jp"

    private static final int primeraHoraConst = 7
    private static final int ultimaHoraConst = 16

    def selectBusquedaRenderNoSelectionOptionImpl(out, noSelectionKey, noSelectionValue, value) {
        logger.error("selectBusquedaRenderNoSelectionOptionImpl - noSelectionKey: " + noSelectionKey + " - value: " + value)
        // If a label for the '--Please choose--' first item is supplied, write it out
        out << "<option data-value=\"${(noSelectionKey == null ? '' : noSelectionKey)}\"${(noSelectionKey == value || (noSelectionKey =='' && value==null)) ? ' selected' : ''}>${noSelectionValue.encodeAsHTML()}</option>"
    }

    private void selectBusquedaWriteValueAndCheckIfSelected(selectName, keyValue, value, writer, dataAttrsMap, el, keyDisabled) {

        boolean selected = false
        def keyClass = keyValue?.getClass()
        if (keyClass.isInstance(value)) {
            selected = (keyValue == value)
        }
        else if (value instanceof Collection) {
            // first try keyValue
            selected = value.contains(keyValue)
            if (!selected && el != null) {
                selected = value.contains(el)
            }
        }
        // GRAILS-3596: Make use of Groovy truth to handle GString <-> String
        // and other equivalent types (such as numbers, Integer <-> Long etc.).
        else if (keyValue == value) {
            selected = true
        }
        else if (keyClass && value != null) {
            try {
                value = conversionService.convert(value, keyClass)
                selected = keyValue == value
            }
            catch (e) {
                // ignore
            }
        }
        keyValue = processFormFieldValueIfNecessary(selectName, "${keyValue}","option")
        writer << "data-value=\"${keyValue.toString().encodeAsHTML()}\" "

        if(dataAttrsMap) {
            dataAttrsMap.each {key, val->
                writer << "data-${key.toString().encodeAsHTML()}=\"${val.toString().encodeAsHTML()}\""
            }
        }
        if (selected) {
            writer << ' selected '
        }
        if(keyDisabled && !selected) {
            writer << ' disabled '
        }
    }

    /**
     * A simple date picker that renders a date as selects.<br/>
     * e.g. &lt;g:datePicker name="myDate" value="${new Date()}" /&gt;
     *
     * @emptyTag
     *
     * @attr name REQUIRED The name of the date picker field set
     * @attr value The current value of the date picker; defaults to either the value specified by the default attribute or now if no default is set
     * @attr default A Date or parsable date string that will be used if there is no value
     * @attr precision The desired granularity of the date to be rendered
     * @attr noSelection A single-entry map detailing the key and value to use for the "no selection made" choice in the select box. If there is no current selection this will be shown as it is first in the list, and if submitted with this selected, the key that you provide will be submitted. Typically this will be blank.
     * @attr years A list or range of years to display, in the order specified. i.e. specify 2007..1900 for a reverse order list going back to 1900. If this attribute is not specified, a range of years from the current year - 100 to current year + 100 will be shown.
     * @attr relativeYears A range of int representing values relative to value. For example, a relativeYears of -2..7 and a value of today will render a list of 10 years starting with 2 years ago through 7 years in the future. This can be useful for things like credit card expiration dates or birthdates which should be bound relative to today.
     * @attr id the DOM element id
     * @attr disabled Makes the resulting inputs and selects to be disabled. Is treated as a Groovy Truth.
     * @attr readonly Makes the resulting inputs and selects to be made read only. Is treated as a Groovy Truth.
     */
    Closure hourPicker = { attrs ->
        logger.info("****** hourPicker() ****")
        def out = out // let x = x ?
        def xdefault = attrs['default']
        if (xdefault == null) {
            xdefault = new Date()
        }
        else if (xdefault.toString() != 'none') {
            if (xdefault instanceof String) {
                xdefault = DateFormat.getInstance().parse(xdefault)

            }
            else if (!grailsTagDateHelper.supportsDatePicker(xdefault.class)) {
                throwTagError("Tag [datePicker] the default date is not a supported class")
            }
        }
        else {
            xdefault = null
        }

        def value = attrs.value
        if (value.toString() == 'none') {
            value = null
        }
        else if (!value) {
            value = xdefault
        }
        def name = attrs.name
        def id = attrs.id ?: name

        def noSelection = attrs.noSelection
        if (noSelection != null) {
            noSelection = noSelection.entrySet().iterator().next()
        }

        // make below final once GROOVY-8093 is fixed
        def hour
        def minute
        def dfs = new DateFormatSymbols(RequestContextUtils.getLocale(request))

        def c = null
        if (value instanceof Calendar) {
            c = value
        }
        else if (value != null) {
            c = grailsTagDateHelper.buildCalendar(value)
        }

        if (c != null) {
            hour = c.get(GregorianCalendar.HOUR_OF_DAY)
            minute = c.get(GregorianCalendar.MINUTE)
        }

        booleanToAttribute(attrs, 'disabled')
        booleanToAttribute(attrs, 'readonly')
        booleanToAttribute(attrs, 'limitarHorario')

        // Change this hidden to use requestDataValueProcessor
        def dateStructValue = processFormFieldValueIfNecessary("${name}","date.struct","hidden")
        out.println "<input type=\"hidden\" name=\"${name}\" value=\"${dateStructValue}\" />"

        out.println "<input type=\"hidden\" name=\"${name}_year\" value=\"${2000}\" />"
        out.println "<input type=\"hidden\" name=\"${name}_month\" value=\"${1}\" />"
        out.println "<input type=\"hidden\" name=\"${name}_day\" value=\"${1}\" />"

        //CREAR HORAS
        out.println "<select name=\"${name}_hour\" id=\"${id}_hour\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect'"
        if (attrs.disabled) {
            out << ' disabled="disabled"'
        }
        if (attrs.readonly) {
            out << ' readonly="readonly"'
        }
        out << '>'

        if (noSelection) {
            renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
            out.println()
        }

        if (attrs.limitarHorario) {
            int primeraHora = primeraHoraConst // cl.horaInicio
            int ultimaHora = ultimaHoraConst // cl.horaFin
            for (i in primeraHora..ultimaHora) {
                def h = '' + i
                if (i < 10) h = '0' + h
                // This option add hour to requestDataValueProcessor
                h  = processFormFieldValueIfNecessary("${name}_hour","${h}","option")
                out.println "<option value=\"${h}\"${i == hour ? ' selected="selected"' : ''}>$h</option>"
            }
        }
        else {
            for (i in 0..23) {
                def h = '' + i
                if (i < 10) h = '0' + h
                // This option add hour to requestDataValueProcessor
                h  = processFormFieldValueIfNecessary("${name}_hour","${h}","option")
                out.println "<option value=\"${h}\"${i == hour ? ' selected="selected"' : ''}>$h</option>"
            }
        }
        out.println '</select> :'

        //CREAR MINUTOS
        out.println "<select name=\"${name}_minute\" id=\"${id}_minute\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect' "
        if (attrs.disabled) {
            out << 'disabled="disabled"'
        }
        if (attrs.readonly) {
            out << 'readonly="readonly"'
        }
        out << '>'

        if (noSelection) {
            renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
            out.println()
        }

        for (i in [0,15,30,45]) {
            def m = '' + i
            if (i < 10) m = '0' + m
            m  = processFormFieldValueIfNecessary("${name}_minute","${m}","option")
            out.println "<option value=\"${m}\"${i == minute ? ' selected="selected"' : ''}>$m</option>"
        }
        out.println '</select>'
    }

    /**
     * A simple date picker that renders a date as selects.<br/>
     * e.g. &lt;g:datePicker name="myDate" value="${new Date()}" /&gt;
     *
     * @emptyTag
     *
     * @attr name REQUIRED The name of the date picker field set
     * @attr value The current value of the date picker; defaults to either the value specified by the default attribute or now if no default is set
     * @attr default A Date or parsable date string that will be used if there is no value
     * @attr precision The desired granularity of the date to be rendered
     * @attr noSelection A single-entry map detailing the key and value to use for the "no selection made" choice in the select box. If there is no current selection this will be shown as it is first in the list, and if submitted with this selected, the key that you provide will be submitted. Typically this will be blank.
     * @attr years A list or range of years to display, in the order specified. i.e. specify 2007..1900 for a reverse order list going back to 1900. If this attribute is not specified, a range of years from the current year - 100 to current year + 100 will be shown.
     * @attr relativeYears A range of int representing values relative to value. For example, a relativeYears of -2..7 and a value of today will render a list of 10 years starting with 2 years ago through 7 years in the future. This can be useful for things like credit card expiration dates or birthdates which should be bound relative to today.
     * @attr id the DOM element id
     * @attr disabled Makes the resulting inputs and selects to be disabled. Is treated as a Groovy Truth.
     * @attr readonly Makes the resulting inputs and selects to be made read only. Is treated as a Groovy Truth.
     */
    Closure datePicker = { attrs ->
        logger.info("****** datePicker() ****")
        def out = out // let x = x ?
        def xdefault = attrs['default']
        if (xdefault == null) {
            xdefault = new Date()
        }
        else if (xdefault.toString() != 'none') {
            if (xdefault instanceof String) {
                xdefault = DateFormat.getInstance().parse(xdefault)

            }
            else if (!grailsTagDateHelper.supportsDatePicker(xdefault.class)) {
                throwTagError("Tag [datePicker] the default date is not a supported class")
            }
        }
        else {
            xdefault = null
        }
        def years = attrs.years
        def relativeYears = attrs.relativeYears
        if (years != null && relativeYears != null) {
            throwTagError 'Tag [datePicker] does not allow both the years and relativeYears attributes to be used together.'
        }

        if (relativeYears != null) {
            if (!(relativeYears instanceof IntRange)) {
                // allow for a syntax like relativeYears="[-2..5]".  The value there is a List containing an IntRage.
                if ((!(relativeYears instanceof List)) || (relativeYears.size() != 1) || (!(relativeYears[0] instanceof IntRange))) {
                    throwTagError 'The [datePicker] relativeYears attribute must be a range of int.'
                }
                relativeYears = relativeYears[0]
            }
        }
        def value = attrs.value
        if (value.toString() == 'none') {
            value = null
        }
        else if (!value) {
            value = xdefault
        }
        def name = attrs.name
        def id = attrs.id ?: name

        def noSelection = attrs.noSelection
        if (noSelection != null) {
            noSelection = noSelection.entrySet().iterator().next()
        }

        // make below final once GROOVY-8093 is fixed
        def PRECISION_RANKINGS = ["year": 0, "month": 10, "day": 20, "hour": 30, "minute": 40]
        def precision = (attrs.precision ? PRECISION_RANKINGS[attrs.precision] :
                (grailsApplication.config.grails.tags.datePicker.default.precision ?
                        PRECISION_RANKINGS["${grailsApplication.config.grails.tags.datePicker.default.precision}"] :
                        PRECISION_RANKINGS["minute"]))

        def day
        def month
        def year
        def hour
        def minute
        def dfs = new DateFormatSymbols(RequestContextUtils.getLocale(request))

        def c = null
        if (value instanceof Calendar) {
            c = value
        }
        else if (value != null) {
            c = grailsTagDateHelper.buildCalendar(value)
        }

        if (c != null) {
            day = c.get(GregorianCalendar.DAY_OF_MONTH)
            month = c.get(GregorianCalendar.MONTH)
            year = c.get(GregorianCalendar.YEAR)
            hour = c.get(GregorianCalendar.HOUR_OF_DAY)
            minute = c.get(GregorianCalendar.MINUTE)
        }

        if (years == null) {
            def tempyear
            if (year == null) {
                // If no year, we need to get current year to setup a default range... ugly
                def tempc = new GregorianCalendar()
                tempc.setTime(new Date())
                tempyear = tempc.get(GregorianCalendar.YEAR)
            }
            else {
                tempyear = year
            }
            if (relativeYears) {
                if (relativeYears.reverse) {
                    years = (tempyear + relativeYears.toInt)..(tempyear + relativeYears.fromInt)
                } else {
                    years = (tempyear + relativeYears.fromInt)..(tempyear + relativeYears.toInt)
                }
            } else {
                years = (tempyear + 100)..(tempyear - 100)
            }
        }

        booleanToAttribute(attrs, 'disabled')
        booleanToAttribute(attrs, 'readonly')
        booleanToAttribute(attrs, 'limitarHorario')

        // Change this hidden to use requestDataValueProcessor
        def dateStructValue = processFormFieldValueIfNecessary("${name}","date.struct","hidden")
        out.println "<input type=\"hidden\" name=\"${name}\" value=\"${dateStructValue}\" />"


        // create year select
        if (precision >= PRECISION_RANKINGS["year"]) {
            out.println "<select name=\"${name}_year\" id=\"${id}_year\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect'"
            if (attrs.disabled) {
                out << ' disabled="disabled"'
            }
            if (attrs.readonly) {
                out << ' readonly="readonly"'
            }
            out << '>'

            if (noSelection) {
                renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
                out.println()
            }

            for (i in years) {
                // Change this year option to use requestDataValueProcessor
                def yearIndex  = processFormFieldValueIfNecessary("${name}_year","${i}","option")
                out.println "<option value=\"${yearIndex}\"${i == year ? ' selected="selected"' : ''}>${i}</option>"
            }
            out.println '</select>'
        }

        // create month select
        if (precision >= PRECISION_RANKINGS["month"]) {
            out.println "<select name=\"${name}_month\" id=\"${id}_month\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect'"
            if (attrs.disabled) {
                out << ' disabled="disabled"'
            }
            if (attrs.readonly) {
                out << ' readonly="readonly"'
            }
            out << '>'

            if (noSelection) {
                renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
                out.println()
            }

            dfs.months.eachWithIndex {m, i ->
                if (m) {
                    def monthIndex = i + 1
                    monthIndex = processFormFieldValueIfNecessary("${name}_month","${monthIndex}","option")
                    out.println "<option value=\"${monthIndex}\"${i == month ? ' selected="selected"' : ''}>$m</option>"
                }
            }
            out.println '</select>'
        }

        // create day select
        if (precision >= PRECISION_RANKINGS["day"]) {
            out.println "<select name=\"${name}_day\" id=\"${id}_day\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect'"
            if (attrs.disabled) {
                out << ' disabled="disabled"'
            }
            if (attrs.readonly) {
                out << ' readonly="readonly"'
            }
            out << '>'

            if (noSelection) {
                renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
                out.println()
            }
            java.text.DecimalFormat formatNumero = new java.text.DecimalFormat("00");


            for (i in 1..31) {
                // Change this option to use requestDataValueProcessor
                def dayIndex = processFormFieldValueIfNecessary("${name}_day","${i}","option")
                out.println "<option value=\"${dayIndex}\"${i == day ? ' selected="selected"' : ''}>${formatNumero.format(i)}</option>"
            }
            out.println '</select>'
        }

        // do hour select
        if (precision >= PRECISION_RANKINGS["hour"]) {
            out.println " - <select name=\"${name}_hour\" id=\"${id}_hour\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect'"
            if (attrs.disabled) {
                out << ' disabled="disabled"'
            }
            if (attrs.readonly) {
                out << ' readonly="readonly"'
            }
            out << '>'

            if (noSelection) {
                renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
                out.println()
            }

            if (attrs.limitarHorario) {
                int primeraHora = primeraHoraConst // cl.horaInicio
                int ultimaHora = ultimaHoraConst // cl.horaFin
                for (i in primeraHora..ultimaHora) {
                    def h = '' + i
                    if (i < 10) h = '0' + h
                    // This option add hour to requestDataValueProcessor
                    h  = processFormFieldValueIfNecessary("${name}_hour","${h}","option")
                    out.println "<option value=\"${h}\"${i == hour ? ' selected="selected"' : ''}>$h</option>"
                }
            }
            else {
                for (i in 0..23) {
                    def h = '' + i
                    if (i < 10) h = '0' + h
                    // This option add hour to requestDataValueProcessor
                    h  = processFormFieldValueIfNecessary("${name}_hour","${h}","option")
                    out.println "<option value=\"${h}\"${i == hour ? ' selected="selected"' : ''}>$h</option>"
                }
            }

            out.println '</select> :'

            // If we're rendering the hour, but not the minutes, then display the minutes as 00 in read-only format
            if (precision < PRECISION_RANKINGS["minute"]) {
                out.println '00'
            }
        }

        // do minute select
        if (precision >= PRECISION_RANKINGS["minute"]) {
            out.println "<select name=\"${name}_minute\" id=\"${id}_minute\" aria-labelledby=\"${name}\" class='many-to-one fechaSelect' "
            if (attrs.disabled) {
                out << 'disabled="disabled"'
            }
            if (attrs.readonly) {
                out << 'readonly="readonly"'
            }
            out << '>'

            if (noSelection) {
                renderNoSelectionOptionImpl(out, noSelection.key, noSelection.value, '')
                out.println()
            }

            if (attrs.limitarHorario) {
                for (i in [0,15,30,45]) {
                    def m = '' + i
                    if (i < 10) m = '0' + m
                    m  = processFormFieldValueIfNecessary("${name}_minute","${m}","option")
                    out.println "<option value=\"${m}\"${i == minute ? ' selected="selected"' : ''}>$m</option>"
                }
            }
            else {
                for (i in 0..59) {
                    def m = '' + i
                    if (i < 10) m = '0' + m
                    m  = processFormFieldValueIfNecessary("${name}_minute","${m}","option")
                    out.println "<option value=\"${m}\"${i == minute ? ' selected="selected"' : ''}>$m</option>"
                }
            }

            out.println '</select>'
        }
    }
}
