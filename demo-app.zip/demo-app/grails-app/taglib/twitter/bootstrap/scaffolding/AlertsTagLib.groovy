package twitter.bootstrap.scaffolding

class AlertsTagLib {

    static namespace = "bootstrap"

    def alert = { attrs, body ->
        out << '<div class="alert alert-block ' << attrs.class.tokenize().join(" ") << ' sombraColorLogo">'
        //out << '<a class="close" data-dismiss="alert">&times;</a>'
        out << '<p>'

        if(!body().contains("glyphicon glyphicon-")){ //si ya trae un icono no se desea mostrar 2
            if(!body().contains("<ul>")){
                if(attrs.class.tokenize().contains("alert-info")){
                    out << '<span class="glyphicon glyphicon-info-sign"></span> '
                }
                if(attrs.class.tokenize().contains("alert-danger")){
                    out << '<span class="glyphicon glyphicon-alert"></span> '
                }
                if(attrs.class.tokenize().contains("alert-warning")){
                    out << '<span class="glyphicon glyphicon-chevron-right"></span> '
                }
                if(attrs.class.tokenize().contains("alert-success")){
                    out << '<span class="glyphicon glyphicon-thumbs-up"></span> '
                }
                out << body()
            }
            else {
                String salida = body()
                String icono = ""
                if(attrs.class.tokenize().contains("alert-info")){
                    icono = '<span class="glyphicon glyphicon-info-sign"></span> '
                }
                if(attrs.class.tokenize().contains("alert-danger")){
                    icono = '<span class="glyphicon glyphicon-alert"></span> '
                }
                if(attrs.class.tokenize().contains("alert-warning")){
                    icono = '<span class="glyphicon glyphicon-chevron-right"></span> '
                }
                if(attrs.class.tokenize().contains("alert-success")){
                    icono = '<span class="glyphicon glyphicon-thumbs-up"></span> '
                }
                salida = salida.replace("\">", "\">${icono}")
                out << salida

            }
        } else {
            out << body()
        }
        out << '</p>'
        out << '</div>'
    }
}
