package demo.app

class UsuarioProducto {

    int id
    Usuario usuario
    Producto producto
    Date dateCreated
    Date lastUpdated

    static constraints = {
        id(blank:false, unique:true)
    }

    static mapping = {
        table 'usuario_producto'
        version false
    }

}