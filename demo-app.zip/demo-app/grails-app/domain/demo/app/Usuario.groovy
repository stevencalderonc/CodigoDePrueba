package demo.app

class Usuario {

    int id
    String nombre
    String descripcion
    int edad

    static hasMany = [productos: Producto]
    static belongsTo = [Producto] // para hacer borrado en cascada

    static constraints = {
        id(blank:false, unique:true)
        nombre(blank:false)
        descripcion(blank:false)
        edad(blank:false)

    }

    static mapping = {
        table 'usuario'
        version false
    }

}