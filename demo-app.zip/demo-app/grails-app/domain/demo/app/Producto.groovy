package demo.app

class Producto {

    int id
    String nombre
    String descripcion
    int precio

    static constraints = {
        id(blank:false, unique:true)
        nombre(blank:false)
        descripcion(blank:false)
        precio(blank:false)
    }

    static mapping = {
        table 'producto'
        version false
    }
}
