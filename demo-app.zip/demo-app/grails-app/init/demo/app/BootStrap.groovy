package demo.app

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
