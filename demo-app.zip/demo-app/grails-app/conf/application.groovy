/*
//Límites de tamaño en la subida de archivos, no se si hará falta:
grails.controllers.upload.maxFileSize = 128000000L
grails.controllers.upload.maxRequestSize = 128000000L
*/

/*
info.app.build.date = '@info.app.build.date@'
info.app.externoVersion = '@info.app.externoVersion@'
*/

// The ACCEPT header will not be used for content negotiation for user agents containing the following strings (defaults to the 4 major rendering engines)
grails.mime.disable.accept.header.userAgents = ['Gecko', 'WebKit', 'Presto', 'Trident']
grails.mime.types = [ // the first one is the default format
                      all:           '*/*', // 'all' maps to '*' or the first available format in withFormat
                      atom:          'application/atom+xml',
                      css:           'text/css',
                      csv:           'text/csv',
                      form:          'application/x-www-form-urlencoded',
                      html:          ['text/html','application/xhtml+xml'],
                      js:            'text/javascript',
                      json:          ['application/json', 'text/json'],
                      multipartForm: 'multipart/form-data',
                      rss:           'application/rss+xml',
                      text:          'text/plain',
                      hal:           ['application/hal+json','application/hal+xml'],
                      xml:           ['text/xml', 'application/xml']
]

// URL Mapping Cache Max Size, defaults to 5000
//grails.urlmapping.cache.maxsize = 1000
//Esto permite cachear recursos estáticos (se añade para cachear ckeditor.js)
grails.resources.cachePeriod=604800

// Legacy setting for codec used to encode data with ${}
grails.views.default.codec = "html"

grails.sitemesh.default.layout = 'bootstrap'

// The default scope for controllers. May be prototype, session or singleton.
// If unspecified, controllers are prototype scoped.
grails.controllers.defaultScope = 'singleton'

// GSP settings
grails {
    views {
        gsp {
            encoding = 'UTF-8'
            htmlcodec = 'xml' // use xml escaping instead of HTML4 escaping
            codecs {
                expression = 'html' // escapes values inside ${}
                scriptlet = 'html' // escapes output from scriptlets in GSPs
                taglib = 'none' // escapes output from taglibs
                staticparts = 'none' // escapes output from static template parts
            }
        }
        // escapes all not-encoded output at final stage of outputting
        // filteringCodecForContentType.'text/html' = 'html'
    }
}


grails.converters.encoding = "UTF-8"
// scaffolding templates configuration
grails.scaffolding.templates.domainSuffix = 'Instance'

// Set to false to use the new Grails 1.2 JSONBuilder in the render method
grails.json.legacy.builder = false
// enabled native2ascii conversion of i18n properties files
grails.enable.native2ascii = true
// packages to include in Spring bean scanning
grails.spring.bean.packages = []
// whether to disable processing of multi part requests
grails.web.disable.multipart=false

// request parameters to mask when logging exceptions
grails.exceptionresolver.params.exclude = ['password']

// configure auto-caching of queries by default (if false you can cache individual queries with 'cache: true')
grails.hibernate.cache.queries = false

// configure passing transaction's read-only attribute to Hibernate session, queries and criterias
// set "singleSession = false" OSIV mode in hibernate configuration after enabling
grails.hibernate.pass.readonly = false
// configure passing read-only to OSIV session by default, requires "singleSession = false" OSIV mode
grails.hibernate.osiv.readonly = false

//grails.gorm.failOnError=true
grails.gorm.failOnErrorPackages=true
grails.gorm.autowire=true
grails.gorm.default.mapping = {
    autowire true
}
//grails.gorm.reactor.events = true

//esto ya no funciona, se cambia las listas para usar el taglib <bootstrap:paginate.
//grails.plugins.twitterbootstrap.fixtaglib = true

//Configuración del ckEditor
ckeditor.config='/js/myckconfig.js'


// Configuration of the mail account
grails {
    mail {
        host = "smtp.gmail.com"
        port = 465
        username = "kdcm0126@gmail.com"
        password = "HFya80.95."
        props = ["mail.smtp.auth":"true",
                 "mail.smtp.socketFactory.port":"465",
                 "mail.smtp.socketFactory.class":"javax.net.ssl.SSLSocketFactory",
                 "mail.smtp.socketFactory.fallback":"false"]
    }
}
grails.mail.default.from="kdcm0126@gmail.com"
grails.plugin.springsecurity.ui.forgotPassword.emailBody = 'Estimado $user.username, <br><br> Se ha solicitado reestablecer su contraseña para usted en el sistema. <br><br> Si no lo ha solicitado usted, no haga caso de este correo (nada se ha modificado), en otro caso, siga este <a href="$url" target="_blank"> enlace</a>.<br><br>No responda a este email.<br><br> Un cordial saludo.<br><br>'
grails.plugin.springsecurity.ui.forgotPassword.emailFrom = 'kdcm0126@gmail.com'
grails.plugin.springsecurity.ui.forgotPassword.emailSubject = '[system] Reestablecer Contraseña'


grails.plugin.springsecurity.userLookup.userDomainClassName = 'com.kdcm.seguridad.Usuario'
grails.plugin.springsecurity.userLookup.authorityJoinClassName = 'com.kdcm.seguridad.UsuarioPerfil'
grails.plugin.springsecurity.authority.className = 'com.kdcm.seguridad.Perfil'

securityConfig.logout.filterProcessesUrl= ""

//Para controllar el máximo de sesiones concurrentes por usuario - INICIO
grails.plugin.springsecurity.useHttpSessionEventPublisher = true
grails.plugin.springsecurity.sessionFixationPrevention.alwaysCreateSession = true
grails.plugin.springsecurity.filterChain.filterNames = [ 'securityContextPersistenceFilter',
                                                         'logoutFilter',
                                                         'concurrentSessionFilter',
                                                         'rememberMeAuthenticationFilter',
                                                         'anonymousAuthenticationFilter',
                                                         'exceptionTranslationFilter',
                                                         'filterInvocationInterceptor' ]

grails.plugin.springsecurity.providerNames = [
        'customAuthenticationProvider',
        'anonymousAuthenticationProvider',
        'rememberMeAuthenticationProvider']

//Para controllar el máximo de sesiones concurrentes por usuario - FIN

grails.plugin.springsecurity.apf.storeLastUsername=true //requerido para guardar los fallos de login
grails.plugin.springsecurity.logout.postOnly = false
grails.plugin.springsecurity.successHandler.alwaysUseDefault = false
//2020-06-26 - Creo que el 'defaultTargetUrl' no se esta utilizando porque no hay una accion de login en un controlador
//2020-06-26 - hasta el login en inicio es sobre la URL de iniico y 'alwaysUseDefault' esta a false
grails.plugin.springsecurity.successHandler.defaultTargetUrl = '/index/loggedIn'
grails.plugin.springsecurity.useSecurityEventListener = true
grails.plugin.springsecurity.useSwitchUserFilter = true
grails.plugin.springsecurity.switchUser.targetUrl = '/index/cambioUsuario'


//Fijar el timeout de la session
/*
server.session.timeout =  1800 //secods, 30 minutes
*/
grails.plugin.springsecurity.ui.password.minLength=4
grails.plugin.springsecurity.ui.password.maxLength=64
grails.plugin.springsecurity.ui.password.validationRegex='^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{4,}$'

//Lo COMENTO PORQUE NO TIENE NINGUN CODIGO
/*
grails.plugin.springsecurity.onAuthenticationSuccessEvent = { e, appCtx ->
	// 	handle AuthenticationSuccessEvent --> se gestiona todo en el siguiente
}
*/

grails.plugin.springsecurity.onInteractiveAuthenticationSuccessEvent = { e, appCtx ->
    // handle InteractiveAuthenticationSuccessEvent
    def usuarioService = appCtx.getBean('usuarioService')
    usuarioService.loginUsuario()
}

grails.plugin.springsecurity.securityConfigType = 'InterceptUrlMap'
grails.plugin.springsecurity.interceptUrlMap = [
        //Permisos sin estar logueado:
        /*
        [pattern: '/webdav', access: ['permitAll']],
        [pattern: '/webdav/**', access: ['permitAll']],
         */
        [pattern: '/', access: ['permitAll']],
        [pattern: '/index', access: ['permitAll']],
        [pattern: '/index/index', access: ['permitAll']],
        [pattern: '/index/loggedIn', access: ['permitAll']],
        [pattern: '/index.gsp', access: ['permitAll']],
        [pattern: '/assets/**', access: ['permitAll']],
        [pattern: '/**/favicon.ico', access: ['permitAll']],
        [pattern: '/favicon.ico', access: ['permitAll']],
        [pattern: '/multimediaImagen/mostrarLogo', access: ['permitAll']],
        [pattern: '/multimediaImagen/mostrarTituloInicio', access: ['permitAll']],
        [pattern: '/**/js/**', access: ['permitAll']],
        [pattern: '/**/css/**', access: ['permitAll']],
        [pattern: '/**/images/**', access: ['permitAll']],
        [pattern: '/**/fonts/**', access: ['permitAll']],
        [pattern: '/login', access: ['permitAll']],
        [pattern: '/login*', access: ['permitAll']],
        [pattern: '/login/*', access: ['permitAll']],
        [pattern: '/login/authAjax', access: ['permitAll']],
        [pattern: '/login/authAjax*', access: ['permitAll']],
        [pattern: '/logout', access: ['permitAll']],
        [pattern: '/logout.*', access: ['permitAll']],
        [pattern: '/logout/*', access: ['permitAll']],
        [pattern: '/register/forgotPassword/**', access: ['permitAll']],
        [pattern: '/register/resetPassword**', access: ['permitAll']],
        [pattern: '/j_spring_security_exit_user', access: ['permitAll']],
        [pattern: '/public/**', access: ['permitAll']],
        //[pattern: '/oauth/**', access: ['permitAll']],

        //Opcion de suplantar usuarios
        [pattern: '/login/impersonate', access:                 ['ROLE_SuperAdministrador']],
        [pattern: '/logout/impersonate', access:                ['permitAll']],

        //Pantallas generales aplicación acceso para todos
        [pattern: '/**/index/**',   access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/index',      access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/list/**',    access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/show/**',    access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/showPDF/**', access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/showVideo/**', access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],


        //Pantallas generales aplicación acceso restringido (operador y administrador)
        [pattern: '/**/create/**',                  access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/save/**',                    access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/edit/**',                    access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/update/**',                  access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],
        [pattern: '/**/delete/**',                  access: ['ROLE_UsuarioInterno']], //['isAuthenticated()']],

        //Acceso completo al ROLE_Administrador
        [pattern: '/**',                    access: ['ROLE_Administrador']],

]


//Conexión a la base de datos, comun en todos los entornos
dataSource {
    pooled = true
    jmxExport = true
    //noinspection GroovyAssignabilityCheck
    properties {
        // Documentation for Tomcat JDBC Pool
        // http://tomcat.apache.org/tomcat-7.0-doc/jdbc-pool.html#Common_Attributes
        // https://tomcat.apache.org/tomcat-7.0-doc/api/org/apache/tomcat/jdbc/pool/PoolConfiguration.html
        jmxEnabled = true
        maxWait = 10000
        maxAge = 600000
        timeBetweenEvictionRunsMillis = 5000
        minEvictableIdleTimeMillis = 60000
        validationQuery = "SELECT 1"
        validationQueryTimeout = 3
        validationInterval = 15000
        testOnBorrow = true
        testWhileIdle = true
        testOnReturn = false
        ignoreExceptionOnPreLoad = true
        // http://tomcat.apache.org/tomcat-7.0-doc/jdbc-pool.html#JDBC_interceptors
        jdbcInterceptors = "ConnectionState" //"ConnectionState;StatementCache(max=200)"
        defaultTransactionIsolation = java.sql.Connection.TRANSACTION_READ_COMMITTED // safe default
        // controls for leaked connections
        abandonWhenPercentageFull = 100 // settings are active only when pool is full
        removeAbandonedTimeout = 120
        removeAbandoned = true
        // use JMX console to change this setting at runtime
        logAbandoned = false // causes stacktrace recording overhead, use only for debugging
        // JDBC driver properties
        // Mysql as example
        dbProperties {
            // Mysql specific driver properties
            // http://dev.mysql.com/doc/connector-j/en/connector-j-reference-configuration-properties.html
            // let Tomcat JDBC Pool handle reconnecting -- estaba en false
            autoReconnect=true
            // truncation behaviour
            jdbcCompliantTruncation=false
            // mysql 0-date conversion
            zeroDateTimeBehavior='convertToNull'
            // Tomcat JDBC Pool's StatementCache is used instead, so disable mysql driver's cache
            cachePrepStmts=false
            cacheCallableStmts=false
            // Tomcat JDBC Pool's StatementFinalizer keeps track
            dontTrackOpenResources=true
            // performance optimization: reduce number of SQLExceptions thrown in mysql driver code
            holdResultsOpenOverStatementClose=true
            // enable MySQL query cache - using server prep stmts will disable query caching
            useServerPrepStmts=false
            // metadata caching
            cacheServerConfiguration=true
            cacheResultSetMetadata=true
            metadataCacheSize=100
            // timeouts for TCP/IP
            connectTimeout=15000
            socketTimeout=120000
            // timer tuning (disable)
            maintainTimeStats=false
            enableQueryTimeouts=false
            // misc tuning
            noDatetimeStringSync=true
        }
    }
}
// environment specific settings
environments {
    development {
        dataSource {
            dbCreate = "update" // one of 'create', 'create-drop', 'update', 'validate', ''
            //formatSql = true
            logSql = true
        }
    }
    /*test {
        dataSource {
            dbCreate = "update"
            url = "jdbc:h2:mem:testDb;MVCC=TRUE;LOCK_TIMEOUT=10000;DB_CLOSE_ON_EXIT=FALSE"
        }
    }
    */
    production {
        dataSource {
            dbCreate = "update"
        }
    }
}
hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = false
    jdbc.use_get_generated_keys = true
//  cache.region.factory_class = 'org.hibernate.cache.SingletonEhCacheRegionFactory' // Hibernate 3
    //cache.region.factory_class = 'org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory' // Hibernate 4
    singleSession = true // configure OSIV singleSession mode
    flush.mode = 'manual' // OSIV session flush mode outside of transactional context
    hibernateDirtyChecking = true
}

//Las variables de ubicacion se usan, no quitarlas
environments {
    development {
        //Para desarrollo
        grails.plugin.fields.disableLookupCache = true
        com.jpicadoyasociados.seguridad.numeroUsuariosBBSS=true
        com.jpicadoyasociados.seguridad.numeroMaximoUsuariosInternos=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.numeroMaximoUsuariosExternos=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.numeroMaximoAdmin=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.perfilAdmin='ROLE_Administrador'
        grails.logging.jul.usebridge = true
        grails.mail.overrideAddress="kdcm0126@gmail.com" //evitar envío de emails a clientes en desarrollo
        grails.mail.poolSize=5

        grails.config.locations = [
                //"classpath:application.groovy",
                //"classpath:myconfig.yml",
                //"classpath:myconfig.properties",
                //"file:///etc/app/myconfig.groovy",
                //"file:///etc/app/myconfig.yml",
                "file:./kcCloud.properties"
                //"~/.grails/application.groovy",
                //"~/.grails/myconfig.yml",
                //"~/.grails/myconfig.properties",
                //'file:${catalina.base}/myconfig.groovy',
                //'file:${catalina.base}/myconfig.yml',
                //'file:${catalina.base}/myconfig.properties'
        ]
    }
    production {
        com.jpicadoyasociados.seguridad.numeroUsuariosBBSS=true
        com.jpicadoyasociados.seguridad.numeroMaximoUsuariosInternos=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.numeroMaximoUsuariosExternos=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.numeroMaximoAdmin=-1 //-1 para no limitar
        com.jpicadoyasociados.seguridad.perfilAdmin='ROLE_Administrador'
        //grails.mail.overrideAddress="kdcm0126@gmail.com" //evitar envío de emails a clientes en desarrollo
        grails.logging.jul.usebridge = false
        grails.mail.poolSize=5
        grails.config.locations = [
                //"classpath:application.groovy",
                //"classpath:myconfig.yml",
                //"classpath:myconfig.properties",
                //"file:///etc/app/myconfig.groovy",
                //"file:///etc/app/myconfig.yml",
                //"file:///etc/app/myconfig.properties",
                //"~/.grails/application.groovy",
                //"~/.grails/myconfig.yml",
                //"~/.grails/myconfig.properties",
                //'file:${catalina.base}/myconfig.groovy',
                //'file:${catalina.base}/myconfig.yml',
                'file:${catalina.base}/kcCloud.properties'
        ]
    }
}

